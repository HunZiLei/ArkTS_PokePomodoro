import TaskTable from '@bundle:top.handwer.homeworktasklist/entry/ets/common/database/TaskTable';
import TaskData from '@bundle:top.handwer.homeworktasklist/entry/ets/common/bean/TaskDataDefault';
import Logger from '@bundle:top.handwer.homeworktasklist/entry/ets/common/utils/Logger';
import { TaskItemDialog_ViewOnly } from '@bundle:top.handwer.homeworktasklist/entry/ets/view/TaskItemDialog_ViewOnly';
import promptAction from '@ohos:promptAction';
import CommonConstants from '@bundle:top.handwer.homeworktasklist/entry/ets/common/constants/CommonConsts';
export default class DDLState extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__tasks = new ObservedPropertyObjectPU([], this, "tasks");
        this.__isEditing = new ObservedPropertySimplePU(false
        // @State isOnSearch: boolean = false
        , this, "isEditing");
        this.__dialogIsAddNew = new ObservedPropertySimplePU(true, this, "dialogIsAddNew");
        this.__taskItem = new ObservedPropertyObjectPU(new TaskData()
        // private isDetailAdd: boolean = false
        , this, "taskItem");
        this.firstOpen = true;
        this.taskTable = new TaskTable(() => { });
        this.dialogSelectedIndex = -1;
        this.__ddlC = new ObservedPropertySimplePU(0, this, "ddlC");
        this.__ddlH = new ObservedPropertySimplePU(0, this, "ddlH");
        this.__ddlM = new ObservedPropertySimplePU(0, this, "ddlM");
        this.__ddlE = new ObservedPropertySimplePU(0, this, "ddlE");
        this.deleteTarget = [];
        this.dialogController_view = new CustomDialogController({
            builder: () => {
                let jsDialog = new TaskItemDialog_ViewOnly(this, {
                    taskItem: this.__taskItem
                });
                jsDialog.setController(this.dialogController_view);
                ViewPU.create(jsDialog);
            },
            alignment: DialogAlignment.Bottom,
            customStyle: true
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.tasks !== undefined) {
            this.tasks = params.tasks;
        }
        if (params.isEditing !== undefined) {
            this.isEditing = params.isEditing;
        }
        if (params.dialogIsAddNew !== undefined) {
            this.dialogIsAddNew = params.dialogIsAddNew;
        }
        if (params.taskItem !== undefined) {
            this.taskItem = params.taskItem;
        }
        if (params.firstOpen !== undefined) {
            this.firstOpen = params.firstOpen;
        }
        if (params.taskTable !== undefined) {
            this.taskTable = params.taskTable;
        }
        if (params.dialogSelectedIndex !== undefined) {
            this.dialogSelectedIndex = params.dialogSelectedIndex;
        }
        if (params.ddlC !== undefined) {
            this.ddlC = params.ddlC;
        }
        if (params.ddlH !== undefined) {
            this.ddlH = params.ddlH;
        }
        if (params.ddlM !== undefined) {
            this.ddlM = params.ddlM;
        }
        if (params.ddlE !== undefined) {
            this.ddlE = params.ddlE;
        }
        if (params.deleteTarget !== undefined) {
            this.deleteTarget = params.deleteTarget;
        }
        if (params.dialogController_view !== undefined) {
            this.dialogController_view = params.dialogController_view;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__tasks.purgeDependencyOnElmtId(rmElmtId);
        this.__isEditing.purgeDependencyOnElmtId(rmElmtId);
        this.__dialogIsAddNew.purgeDependencyOnElmtId(rmElmtId);
        this.__taskItem.purgeDependencyOnElmtId(rmElmtId);
        this.__ddlC.purgeDependencyOnElmtId(rmElmtId);
        this.__ddlH.purgeDependencyOnElmtId(rmElmtId);
        this.__ddlM.purgeDependencyOnElmtId(rmElmtId);
        this.__ddlE.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__tasks.aboutToBeDeleted();
        this.__isEditing.aboutToBeDeleted();
        this.__dialogIsAddNew.aboutToBeDeleted();
        this.__taskItem.aboutToBeDeleted();
        this.__ddlC.aboutToBeDeleted();
        this.__ddlH.aboutToBeDeleted();
        this.__ddlM.aboutToBeDeleted();
        this.__ddlE.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get tasks() {
        return this.__tasks.get();
    }
    set tasks(newValue) {
        this.__tasks.set(newValue);
    }
    get isEditing() {
        return this.__isEditing.get();
    }
    set isEditing(newValue) {
        this.__isEditing.set(newValue);
    }
    get dialogIsAddNew() {
        return this.__dialogIsAddNew.get();
    }
    set dialogIsAddNew(newValue) {
        this.__dialogIsAddNew.set(newValue);
    }
    get taskItem() {
        return this.__taskItem.get();
    }
    set taskItem(newValue) {
        this.__taskItem.set(newValue);
    }
    get ddlC() {
        return this.__ddlC.get();
    }
    set ddlC(newValue) {
        this.__ddlC.set(newValue);
    }
    get ddlH() {
        return this.__ddlH.get();
    }
    set ddlH(newValue) {
        this.__ddlH.set(newValue);
    }
    get ddlM() {
        return this.__ddlM.get();
    }
    set ddlM(newValue) {
        this.__ddlM.set(newValue);
    }
    get ddlE() {
        return this.__ddlE.get();
    }
    set ddlE(newValue) {
        this.__ddlE.set(newValue);
    }
    TaskList_ListItem(item, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/DDLState.ets(38:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/IndexTabPages/DDLState.ets(39:7)");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.height(56);
            Row.width('100%');
            Row.padding({ left: 12, right: 12 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/IndexTabPages/DDLState.ets(40:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (!this.isEditing) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Checkbox.create();
                        Checkbox.debugLine("components/IndexTabPages/DDLState.ets(42:13)");
                        Checkbox.select(item.is_completed);
                        Checkbox.onChange((value) => {
                            item.is_completed = value;
                            this.updateExistingTask(item);
                        });
                        Checkbox.margin({ right: 10 });
                        if (!isInitialRender) {
                            Checkbox.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Checkbox.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(item.task_name);
            Text.debugLine("components/IndexTabPages/DDLState.ets(50:11)");
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.maxLines(1);
            Text.width('60%');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/IndexTabPages/DDLState.ets(55:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/DDLState.ets(56:11)");
            Column.alignItems(HorizontalAlign.End);
            Column.margin({ right: 10 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(getDateString(item.due_date_stamp));
            Text.debugLine("components/IndexTabPages/DDLState.ets(57:13)");
            Text.fontSize(16);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(getTimeString(item.due_date_stamp));
            Text.debugLine("components/IndexTabPages/DDLState.ets(59:13)");
            Text.fontSize(13);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (!item.is_completed) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithChild({ type: ButtonType.Circle, });
                        Button.debugLine("components/IndexTabPages/DDLState.ets(64:35)");
                        Button.backgroundColor(CommonConstants.DDL_COLOR[item.getDDLState()]);
                        Button.height(12);
                        Button.width(12);
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(' ');
                        Text.debugLine("components/IndexTabPages/DDLState.ets(65:13)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    Button.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Progress.create({ value: 100 - item.getDDLPer() });
            Progress.debugLine("components/IndexTabPages/DDLState.ets(79:7)");
            Progress.margin({ bottom: 10 });
            Progress.color(CommonConstants.DDL_COLOR[item.getDDLState()]);
            if (!isInitialRender) {
                Progress.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
    }
    TaskList_DDLState(text, state, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(text);
            Text.debugLine("components/IndexTabPages/DDLState.ets(86:5)");
            Text.fontSize(20);
            Text.width('100%');
            Text.margin({ bottom: 10, top: 20 });
            Text.textAlign(TextAlign.Start);
            Text.padding({ left: 12, right: 12 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("components/IndexTabPages/DDLState.ets(93:5)");
            List.width('100%');
            List.borderRadius(20);
            List.divider({ strokeWidth: 1 });
            List.margin({ bottom: 20 });
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 未办事项
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    If.create();
                    if (!item.is_completed && item.getDDLState() == state) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            {
                                const isLazyCreate = true;
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, isLazyCreate);
                                    ListItem.width('100%');
                                    ListItem.backgroundColor(0xffffff);
                                    ListItem.onClick(() => {
                                        this.taskItem = item;
                                        this.dialogController_view.open();
                                    });
                                    ListItem.debugLine("components/IndexTabPages/DDLState.ets(96:64)");
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const observedShallowRender = () => {
                                    this.observeComponentCreation(itemCreation);
                                    ListItem.pop();
                                };
                                const observedDeepRender = () => {
                                    this.observeComponentCreation(itemCreation);
                                    this.TaskList_ListItem.bind(this)(item);
                                    ListItem.pop();
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.updateFuncByElmtId.set(elmtId, itemCreation);
                                    this.TaskList_ListItem.bind(this)(item);
                                    ListItem.pop();
                                };
                                if (isLazyCreate) {
                                    observedShallowRender();
                                }
                                else {
                                    observedDeepRender();
                                }
                            }
                        });
                    }
                    else {
                        If.branchId(1);
                    }
                    if (!isInitialRender) {
                        If.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                If.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tasks, forEachItemGenFunction);
            if (!isInitialRender) {
                // 未办事项
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 未办事项
        ForEach.pop();
        List.pop();
    }
    updateExistingTask(taskData) {
        this.taskTable.updateData(taskData, () => { });
        let new_task = this.tasks;
        this.tasks = [];
        new_task[this.dialogSelectedIndex] = taskData;
        // Logger.debug(`TaskList taskData = ${JSON.stringify(taskData)}`)
        this.tasks = new_task; // 触发 UI 刷新
        this.dialogSelectedIndex = -1;
    }
    querySearchTask(searchVal, callback) {
        // 暂时只写了task_name
        this.taskTable.query(`%${searchVal}%`, (searchRes) => {
            this.tasks = searchRes;
            for (let i = 0; i < this.tasks.length; ++i) {
                this.tasks[i].setDDLState();
                let str = this.tasks[i].getDDLState();
                if (str == 'critical')
                    this.ddlC++;
                else if (str == 'hard')
                    this.ddlH++;
                else if (str == 'medium')
                    this.ddlM++;
                else
                    this.ddlE++;
            }
            callback();
        }, (searchVal == ''));
    }
    // 数据库操作封装 结束
    // 组件生命周期
    aboutToAppear() {
        Logger.debug(`[DDLState] aboutToAppear`);
        if (this.firstOpen) {
            this.taskTable.getRdbStore(() => {
                this.taskTable.query('', (result) => {
                    this.tasks = result;
                    for (let i = 0; i < this.tasks.length; ++i) {
                        this.tasks[i].setDDLState();
                        let str = this.tasks[i].getDDLState();
                        if (str == 'critical')
                            this.ddlC++;
                        else if (str == 'hard')
                            this.ddlH++;
                        else if (str == 'medium')
                            this.ddlM++;
                    }
                    Logger.debug(`TaskData = ${JSON.stringify(this.tasks)}`);
                }, true);
            });
            this.firstOpen = false;
        }
    }
    // 组件生命周期 结束
    // UI
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/DDLState.ets(162:7)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("components/IndexTabPages/DDLState.ets(163:9)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Navigation.create();
            Navigation.debugLine("components/IndexTabPages/DDLState.ets(164:11)");
            Navigation.titleMode(NavigationTitleMode.Mini);
            Navigation.hideBackButton(true);
            Navigation.title('截止时间');
            if (!isInitialRender) {
                Navigation.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            // UI 搜索
            if (!this.isEditing) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Search.create();
                        Search.debugLine("components/IndexTabPages/DDLState.ets(167:34)");
                        Search.onSubmit((value) => {
                            this.querySearchTask(value);
                        });
                        Search.width('90%');
                        if (!isInitialRender) {
                            Search.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Search.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/DDLState.ets(175:13)");
            Column.height('90%');
            Column.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // UI 待办事项界面
            Scroll.create();
            Scroll.debugLine("components/IndexTabPages/DDLState.ets(177:15)");
            // UI 待办事项界面
            Scroll.edgeEffect(EdgeEffect.Spring);
            if (!isInitialRender) {
                // UI 待办事项界面
                Scroll.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/DDLState.ets(178:17)");
            Column.padding({ left: 12, right: 12, bottom: 10, top: 10 });
            Column.justifyContent(FlexAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // UI 待办事项列表
        this.TaskList_DDLState.bind(this)('非常紧急', 'critical');
        this.TaskList_DDLState.bind(this)('紧急', 'hard');
        this.TaskList_DDLState.bind(this)('还有时间', 'medium');
        this.TaskList_DDLState.bind(this)('该开始了', 'easy');
        Column.pop();
        // UI 待办事项界面
        Scroll.pop();
        Column.pop();
        Navigation.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            // UI <临时> 提交入口（只剩刷新按钮了）
            if (!this.isEditing) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("components/IndexTabPages/DDLState.ets(198:32)");
                        Column.padding({ left: 12, right: 12, bottom: 30 });
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("components/IndexTabPages/DDLState.ets(199:13)");
                        Row.justifyContent(FlexAlign.SpaceAround);
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel('刷新');
                        Button.debugLine("components/IndexTabPages/DDLState.ets(200:15)");
                        Button.backgroundColor('#9BDEBB');
                        Button.onClick(() => {
                            promptAction.showToast({ message: '刷新中' });
                            this.querySearchTask('', () => {
                                promptAction.showToast({ message: '刷新成功' });
                            });
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                    Row.pop();
                    Column.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Stack.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function getDateString(date_stamp) {
    let date = new Date();
    date.setTime(date_stamp);
    Logger.debug(`TaskList: datestamp = ${date_stamp}, date = ${date.toLocaleDateString()}`);
    let ds = date.toLocaleDateString().split('/');
    let res = `${ds[2]}/${ds[0]}/${ds[1]}`;
    return res;
}
function getTimeString(date_stamp) {
    let date = new Date();
    date.setTime(date_stamp);
    Logger.debug(`TaskList: datestamp = ${date_stamp}, date = ${date.toLocaleTimeString()}`);
    return date.toLocaleTimeString();
}
//# sourceMappingURL=DDLState.js.map