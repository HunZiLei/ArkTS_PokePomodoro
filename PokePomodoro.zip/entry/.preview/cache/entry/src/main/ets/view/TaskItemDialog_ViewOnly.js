import CommonConstants from '@bundle:top.handwer.homeworktasklist/entry/ets/common/constants/CommonConsts';
import Logger from '@bundle:top.handwer.homeworktasklist/entry/ets/common/utils/Logger';
export class TaskItemDialog_ViewOnly extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__taskItem = new SynchedPropertyObjectTwoWayPU(params.taskItem, this, "taskItem");
        this.controller = undefined;
        this.taskName = undefined;
        this.taskSubject = undefined;
        this.taskDate = undefined;
        this.taskDetailText = undefined;
        this.color_column = '#99DBBA';
        this.color_back = '#A1E6C2';
        this.color_button = '#4BAD96';
        this.__showedTaskDate = new ObservedPropertySimplePU('', this, "showedTaskDate");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.taskName !== undefined) {
            this.taskName = params.taskName;
        }
        if (params.taskSubject !== undefined) {
            this.taskSubject = params.taskSubject;
        }
        if (params.taskDate !== undefined) {
            this.taskDate = params.taskDate;
        }
        if (params.taskDetailText !== undefined) {
            this.taskDetailText = params.taskDetailText;
        }
        if (params.color_column !== undefined) {
            this.color_column = params.color_column;
        }
        if (params.color_back !== undefined) {
            this.color_back = params.color_back;
        }
        if (params.color_button !== undefined) {
            this.color_button = params.color_button;
        }
        if (params.showedTaskDate !== undefined) {
            this.showedTaskDate = params.showedTaskDate;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__taskItem.purgeDependencyOnElmtId(rmElmtId);
        this.__showedTaskDate.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__taskItem.aboutToBeDeleted();
        this.__showedTaskDate.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get taskItem() {
        return this.__taskItem.get();
    }
    set taskItem(newValue) {
        this.__taskItem.set(newValue);
    }
    setController(ctr) {
        this.
        // @Link dialogIsAddNew: boolean
        controller = ctr;
    }
    get showedTaskDate() {
        return this.__showedTaskDate.get();
    }
    set showedTaskDate(newValue) {
        this.__showedTaskDate.set(newValue);
    }
    aboutToAppear() {
        this.taskName = this.taskItem.task_name;
        this.taskSubject = this.taskItem.subject;
        this.taskDetailText = this.taskItem.detail;
        this.taskDate = new Date();
        Logger.debug('TaskItemDialog new date = ' + this.taskDate.toLocaleString());
        this.taskDate.setTime(this.taskItem.due_date_stamp);
        this.showedTaskDate = getTimeString(this.taskDate.getTime());
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/TaskItemDialog_ViewOnly.ets(34:5)");
            Column.backgroundColor(this.color_back);
            Column.width('100%');
            Column.height('60%');
            Column.borderRadius(24);
            Column.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777232, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
            Image.debugLine("view/TaskItemDialog_ViewOnly.ets(35:7)");
            Image.width(64);
            Image.height(24);
            Image.onClick(() => {
                var _a;
                (_a = this.controller) === null || _a === void 0 ? void 0 : _a.close();
            });
            Image.margin({ top: 5 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/TaskItemDialog_ViewOnly.ets(42:7)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/TaskItemDialog_ViewOnly.ets(43:9)");
            Column.padding({ left: 16, right: 16 });
            Column.margin({ bottom: 20 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('任务名称');
            Text.debugLine("view/TaskItemDialog_ViewOnly.ets(44:11)");
            Text.fontSize(18);
            Text.alignSelf(ItemAlign.Start);
            Text.margin({ top: 12, bottom: 12 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.taskName);
            Text.debugLine("view/TaskItemDialog_ViewOnly.ets(48:11)");
            Text.backgroundColor(this.color_column);
            Text.margin({ bottom: 10 });
            Text.height(50);
            Text.width('90%');
            Text.borderRadius(24);
            Text.padding({ left: 12, right: 12 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // TextInput({
            //   placeholder: '作业科目',
            //   text: this.taskSubject == 0 ? '' : this.taskSubject.toString()
            // })
            //   .backgroundColor(0xf1f2f3)
            //   .height(50)
            //   .margin({ bottom: 20 })
            //   .onChange((value: string) => {
            //     this.taskSubject = Number(value)
            //   })
            Text.create('详细内容');
            Text.debugLine("view/TaskItemDialog_ViewOnly.ets(65:11)");
            // TextInput({
            //   placeholder: '作业科目',
            //   text: this.taskSubject == 0 ? '' : this.taskSubject.toString()
            // })
            //   .backgroundColor(0xf1f2f3)
            //   .height(50)
            //   .margin({ bottom: 20 })
            //   .onChange((value: string) => {
            //     this.taskSubject = Number(value)
            //   })
            Text.fontSize(18);
            // TextInput({
            //   placeholder: '作业科目',
            //   text: this.taskSubject == 0 ? '' : this.taskSubject.toString()
            // })
            //   .backgroundColor(0xf1f2f3)
            //   .height(50)
            //   .margin({ bottom: 20 })
            //   .onChange((value: string) => {
            //     this.taskSubject = Number(value)
            //   })
            Text.alignSelf(ItemAlign.Start);
            // TextInput({
            //   placeholder: '作业科目',
            //   text: this.taskSubject == 0 ? '' : this.taskSubject.toString()
            // })
            //   .backgroundColor(0xf1f2f3)
            //   .height(50)
            //   .margin({ bottom: 20 })
            //   .onChange((value: string) => {
            //     this.taskSubject = Number(value)
            //   })
            Text.margin({ top: 12, bottom: 12 });
            if (!isInitialRender) {
                // TextInput({
                //   placeholder: '作业科目',
                //   text: this.taskSubject == 0 ? '' : this.taskSubject.toString()
                // })
                //   .backgroundColor(0xf1f2f3)
                //   .height(50)
                //   .margin({ bottom: 20 })
                //   .onChange((value: string) => {
                //     this.taskSubject = Number(value)
                //   })
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // TextInput({
        //   placeholder: '作业科目',
        //   text: this.taskSubject == 0 ? '' : this.taskSubject.toString()
        // })
        //   .backgroundColor(0xf1f2f3)
        //   .height(50)
        //   .margin({ bottom: 20 })
        //   .onChange((value: string) => {
        //     this.taskSubject = Number(value)
        //   })
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.taskDetailText);
            Text.debugLine("view/TaskItemDialog_ViewOnly.ets(69:11)");
            Text.height(50 * 3);
            Text.width('90%');
            Text.borderRadius(24);
            Text.backgroundColor(this.color_column);
            Text.padding({ left: 12, right: 12, top: 12, bottom: 12 });
            Text.align(Alignment.TopStart);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('截止日期：' + this.showedTaskDate);
            Text.debugLine("view/TaskItemDialog_ViewOnly.ets(78:9)");
            Text.width('80%');
            Text.height(50);
            Text.padding({ left: 12, right: 12 });
            Text.borderRadius(24);
            Text.backgroundColor(this.color_column);
            Text.fontColor(0x000000);
            Text.textAlign(TextAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Progress.create({ value: 100 - this.taskItem.getDDLPer() });
            Progress.debugLine("view/TaskItemDialog_ViewOnly.ets(87:9)");
            Progress.margin({ bottom: 10, top: 10 });
            Progress.color(CommonConstants.DDL_COLOR[this.taskItem.getDDLState()]);
            if (!isInitialRender) {
                Progress.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // .margin({ bottom: 10 })
            Row.create();
            Row.debugLine("view/TaskItemDialog_ViewOnly.ets(92:9)");
            // .margin({ bottom: 10 })
            Row.margin({ bottom: 20 });
            if (!isInitialRender) {
                // .margin({ bottom: 10 })
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // Button('取消')
            //   .margin({ right: 10 })
            //   .onClick(() => {
            //     this.controller.close()
            //   })
            Button.createWithLabel('确定');
            Button.debugLine("view/TaskItemDialog_ViewOnly.ets(98:11)");
            // Button('取消')
            //   .margin({ right: 10 })
            //   .onClick(() => {
            //     this.controller.close()
            //   })
            Button.backgroundColor(this.color_button);
            // Button('取消')
            //   .margin({ right: 10 })
            //   .onClick(() => {
            //     this.controller.close()
            //   })
            Button.onClick(() => {
                // this.taskItem.subject = this.taskSubject
                // this.taskItem.task_name = this.taskName
                // this.taskItem.detail = this.taskDetailText
                // this.taskItem.due_date_stamp = this.taskDate.getTime()
                // Logger.debug(`TaskItemDialog due_date(stamp): ${this.taskItem.due_date_stamp}, date: ${this.taskDate.toDateString()}`)
                // this.confirm(this.dialogIsAddNew, this.taskItem)
                this.controller.close();
            });
            if (!isInitialRender) {
                // Button('取消')
                //   .margin({ right: 10 })
                //   .onClick(() => {
                //     this.controller.close()
                //   })
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // Button('取消')
        //   .margin({ right: 10 })
        //   .onClick(() => {
        //     this.controller.close()
        //   })
        Button.pop();
        // .margin({ bottom: 10 })
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function getTimeString(date_stamp) {
    let date = new Date();
    date.setTime(date_stamp);
    Logger.debug(`TaskList: datestamp = ${date_stamp}, date = ${date.toLocaleDateString()}`);
    let ds = date.toLocaleDateString().split('/');
    let res = `${ds[2]}/${ds[0]}/${ds[1]} `;
    return res + date.toLocaleTimeString();
}
//# sourceMappingURL=TaskItemDialog_ViewOnly.js.map