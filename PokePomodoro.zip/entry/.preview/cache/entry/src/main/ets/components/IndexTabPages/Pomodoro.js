export class Pomodoro extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.textTimerController = new TextTimerController();
        this.format = 'mm:ss.SS';
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.textTimerController !== undefined) {
            this.textTimerController = params.textTimerController;
        }
        if (params.format !== undefined) {
            this.format = params.format;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/Pomodoro.ets(10:5)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Navigation.create();
            Navigation.debugLine("components/IndexTabPages/Pomodoro.ets(11:7)");
            Navigation.borderColor('#ED165B');
            Navigation.title('番茄钟');
            Navigation.titleMode(NavigationTitleMode.Full);
            if (!isInitialRender) {
                Navigation.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/Pomodoro.ets(12:9)");
            Column.padding({ left: 12, right: 12, bottom: 10, top: 10 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextTimer.create({ isCountDown: false, count: 300000, controller: this.textTimerController });
            TextTimer.debugLine("components/IndexTabPages/Pomodoro.ets(13:13)");
            TextTimer.format(this.format);
            TextTimer.margin({ top: 25, bottom: 20, right: 200, left: 200 });
            TextTimer.fontColor(Color.Black);
            TextTimer.fontSize(50);
            TextTimer.onTimer((utc, elapsedTime) => {
                console.info('textTimer is：' + utc + ', elapsedTime is: ' + elapsedTime);
            });
            if (!isInitialRender) {
                TextTimer.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TextTimer.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("计时开始");
            Button.debugLine("components/IndexTabPages/Pomodoro.ets(22:13)");
            Button.backgroundColor('#9BDEBB');
            Button.type(ButtonType.Normal);
            Button.margin({ top: 20, bottom: 10 });
            Button.borderRadius(24);
            Button.width(160);
            Button.height(60);
            Button.fontSize(24);
            Button.onClick(() => {
                this.textTimerController.start();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("暂停计时");
            Button.debugLine("components/IndexTabPages/Pomodoro.ets(34:13)");
            Button.backgroundColor('#9BDEBB');
            Button.type(ButtonType.Normal);
            Button.borderRadius(24);
            Button.margin({ bottom: 10 });
            Button.width(160);
            Button.height(60);
            Button.fontSize(24);
            Button.onClick(() => {
                this.textTimerController.pause();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("重置");
            Button.debugLine("components/IndexTabPages/Pomodoro.ets(46:13)");
            Button.backgroundColor('#9BDEBB');
            Button.type(ButtonType.Normal);
            Button.borderRadius(24);
            Button.width(160);
            Button.height(60);
            Button.fontSize(24);
            Button.onClick(() => {
                this.textTimerController.reset();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777257, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
            Image.debugLine("components/IndexTabPages/Pomodoro.ets(59:9)");
            Image.position({ x: '10%', y: '10%' });
            Image.size({ width: '60vp', height: '60vp' });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Navigation.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Pomodoro(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Pomodoro.js.map