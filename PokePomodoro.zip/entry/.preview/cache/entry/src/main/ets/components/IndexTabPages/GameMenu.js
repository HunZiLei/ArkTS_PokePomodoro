import router from '@ohos:router';
import { getNews, getTips } from '@bundle:top.handwer.homeworktasklist/entry/ets/model/newsModel';
export class GameManu extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.swiperController = new SwiperController();
        this.textTimerController = new TextTimerController();
        this.format = 'mm:ss.SS';
        this.newsList = getNews();
        this.tipsList = getTips();
        this.questionList = [
            '    在一个国家里，居民要么总是说真话，要么总是说谎话。有两个人，甲和乙，一个是说真话的，另一个是说谎话的。甲说：“我们两个都是说谎话的。”\n请问：甲的陈述是正确的吗？',
            '    有三个箱子，但它们都被错误地标上了一个标签。你只能打开一个箱子，看到里面的物品。\n请问：如果你打开的箱子上的标签是正确的，那么其他两个箱子的标签是正确的吗？',
            '    有三个人，A、B、C，他们生活在不同的时代。A说：“B是未来的人。” B说：“C是过去的人。” C说：“A和B都是过去的人。”\n请问：这三个人的说法是否一致？'
        ];
        this.__currTipsIndex = new ObservedPropertySimplePU(1, this, "currTipsIndex");
        this.__currTips = new ObservedPropertySimplePU('', this, "currTips");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.swiperController !== undefined) {
            this.swiperController = params.swiperController;
        }
        if (params.textTimerController !== undefined) {
            this.textTimerController = params.textTimerController;
        }
        if (params.format !== undefined) {
            this.format = params.format;
        }
        if (params.newsList !== undefined) {
            this.newsList = params.newsList;
        }
        if (params.tipsList !== undefined) {
            this.tipsList = params.tipsList;
        }
        if (params.questionList !== undefined) {
            this.questionList = params.questionList;
        }
        if (params.currTipsIndex !== undefined) {
            this.currTipsIndex = params.currTipsIndex;
        }
        if (params.currTips !== undefined) {
            this.currTips = params.currTips;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currTipsIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__currTips.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currTipsIndex.aboutToBeDeleted();
        this.__currTips.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get currTipsIndex() {
        return this.__currTipsIndex.get();
    }
    set currTipsIndex(newValue) {
        this.__currTipsIndex.set(newValue);
    }
    get currTips() {
        return this.__currTips.get();
    }
    set currTips(newValue) {
        this.__currTips.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/GameMenu.ets(22:5)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Navigation.create();
            Navigation.debugLine("components/IndexTabPages/GameMenu.ets(23:7)");
            Navigation.borderColor('#ED165B');
            Navigation.title('休息一下');
            Navigation.titleMode(NavigationTitleMode.Full);
            if (!isInitialRender) {
                Navigation.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/GameMenu.ets(24:9)");
            Column.backgroundImage({ "id": 16777286, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
            Column.backgroundImageSize({ width: '100%', height: '45%' });
            Column.size({ width: '95%', height: '60%' });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('你知道吗？');
            Text.debugLine("components/IndexTabPages/GameMenu.ets(25:11)");
            Text.fontSize('32vp');
            Text.margin({ bottom: '5vp' });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Swiper.create(this.swiperController);
            Swiper.debugLine("components/IndexTabPages/GameMenu.ets(29:11)");
            Swiper.duration(1000);
            Swiper.interval(5020);
            Swiper.autoPlay(true);
            Swiper.loop(true);
            Swiper.cachedCount(2);
            Swiper.borderRadius(20);
            Swiper.width('95%');
            if (!isInitialRender) {
                Swiper.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("components/IndexTabPages/GameMenu.ets(31:15)");
                    Column.width('90%');
                    Column.height(160);
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(item);
                    Text.debugLine("components/IndexTabPages/GameMenu.ets(32:17)");
                    Text.fontColor(Color.White);
                    Text.fontSize('25vp');
                    Text.textAlign(TextAlign.Center);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tipsList, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Swiper.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/IndexTabPages/GameMenu.ets(49:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777250, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
            Image.debugLine("components/IndexTabPages/GameMenu.ets(50:13)");
            Image.size({ width: '30vp', height: '30vp' });
            Image.position({ x: '90%', y: '35%' });
            Image.onClick(() => {
                this.currTipsIndex = (this.currTipsIndex + 1) % this.tipsList.length;
                console.info('###Click: ' + this.currTipsIndex);
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/GameMenu.ets(63:9)");
            Column.backgroundImage({ "id": 16777260, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
            Column.backgroundImageSize({ width: '100%', height: '100%' });
            Column.markAnchor({ x: '50%' });
            Column.position({ x: '50%', y: '30%' });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('今日新闻');
            Text.debugLine("components/IndexTabPages/GameMenu.ets(64:11)");
            Text.fontSize('32vp');
            Text.fontColor(Color.White);
            Text.margin({ right: '150vp', bottom: '5vp' });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Swiper.create(this.swiperController);
            Swiper.debugLine("components/IndexTabPages/GameMenu.ets(68:11)");
            Swiper.duration(1000);
            Swiper.interval(4000);
            Swiper.autoPlay(true);
            Swiper.loop(true);
            Swiper.cachedCount(2);
            Swiper.borderRadius(20);
            Swiper.width('95%');
            if (!isInitialRender) {
                Swiper.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("components/IndexTabPages/GameMenu.ets(70:15)");
                    Column.onClick(() => {
                        router.pushUrl({
                            url: 'pages/newsWeb',
                            params: {
                                url: item.url
                            }
                        }, router.RouterMode.Single, (err) => {
                            if (err) {
                                console.error(`###Invoke pushUrl failed, code is ${err.code}, message is ${err.message}`);
                                return;
                            }
                            console.info('###Invoke pushUrl succeeded.');
                        });
                    });
                    Column.width('90%');
                    Column.height(160);
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(item.date);
                    Text.debugLine("components/IndexTabPages/GameMenu.ets(71:17)");
                    Text.textAlign(TextAlign.Start);
                    Text.fontSize('20vp');
                    Text.fontColor('#A6EDC8');
                    Text.margin({ bottom: '15vp' });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(item.title);
                    Text.debugLine("components/IndexTabPages/GameMenu.ets(76:17)");
                    Text.fontColor(Color.White);
                    Text.fontSize('30vp');
                    Text.textAlign(TextAlign.Center);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.newsList, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Swiper.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/GameMenu.ets(112:9)");
            Column.size({ width: '95%', height: '34%' });
            Column.backgroundImage({ "id": 16777291, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
            Column.backgroundImageSize({ width: '100%', height: '100%' });
            Column.markAnchor({ x: '50%' });
            Column.position({ x: '50%', y: '64%' });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Swiper.create(this.swiperController);
            Swiper.debugLine("components/IndexTabPages/GameMenu.ets(113:11)");
            Swiper.duration(1000);
            Swiper.indicator(false);
            Swiper.loop(true);
            Swiper.cachedCount(2);
            Swiper.borderRadius(20);
            Swiper.width('95%');
            Swiper.height('80%');
            if (!isInitialRender) {
                Swiper.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(item);
                    Text.debugLine("components/IndexTabPages/GameMenu.ets(115:15)");
                    Text.fontColor(Color.White);
                    Text.fontSize('20vp');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, this.questionList, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Swiper.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/IndexTabPages/GameMenu.ets(127:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle });
            Button.debugLine("components/IndexTabPages/GameMenu.ets(128:13)");
            Button.size({ width: '40vp', height: '40vp' });
            Button.backgroundColor(Color.Green);
            Button.margin({ left: '20vp', top: '0vp' });
            Button.markAnchor({ x: '50%' });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('√');
            Text.debugLine("components/IndexTabPages/GameMenu.ets(129:15)");
            Text.fontSize('15vp');
            Text.fontColor(Color.White);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle });
            Button.debugLine("components/IndexTabPages/GameMenu.ets(138:13)");
            Button.margin({ left: '20vp', top: '00vp' });
            Button.markAnchor({ x: '50%' });
            Button.size({ width: '40vp', height: '40vp' });
            Button.backgroundColor(Color.Red);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('X');
            Text.debugLine("components/IndexTabPages/GameMenu.ets(139:15)");
            Text.fontSize('15vp');
            Text.fontColor(Color.White);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Button.pop();
        Row.pop();
        Column.pop();
        Navigation.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new GameManu(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=GameMenu.js.map