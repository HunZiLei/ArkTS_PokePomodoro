import http from '@ohos:net.http';
import prompt from '@ohos:prompt';
import { HomeTabs } from '@bundle:top.handwer.homeworktasklist/entry/ets/pages/customCpt/homeTabs';
import { getTest } from '@bundle:top.handwer.homeworktasklist/entry/ets/model/newsModel';
import { LoadingDialog } from '@bundle:top.handwer.homeworktasklist/entry/ets/pages/customDialog/loadingDialog';
export class HomePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.loadingDialog = new CustomDialogController({
            builder: () => {
                let jsDialog = new LoadingDialog(this, {});
                jsDialog.setController(this.loadingDialog);
                ViewPU.create(jsDialog);
            },
            customStyle: true
        }, this);
        this.isShowLoadingDialog = true;
        this.__listNews = new ObservedPropertyObjectPU(new Array()
        // 新闻类型
        , this, "listNews");
        this.tabType = 'guonei';
        this.pageNo = 1;
        this.__offsetY = new ObservedPropertySimplePU(0
        // 按下的y坐标
        , this, "offsetY");
        this.downY = 0;
        this.lastMoveY = 0;
        this.startIndex = 0;
        this.endIndex = 0;
        this.pullRefreshHeight = 70;
        this.__pullRefreshText = new ObservedPropertySimplePU('下拉刷新'
        // 下拉刷新图标：与文字对应
        , this, "pullRefreshText");
        this.__pullRefreshImage = new ObservedPropertyObjectPU({ "id": 16777230, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" }, this, "pullRefreshImage");
        this.isCanRefresh = false;
        this.isRefreshing = false;
        this.isPullRefreshOperation = false;
        this.loadMoreHeight = 70;
        this.__isVisibleLoadMore = new ObservedPropertySimplePU(false
        // 是否可以加载更多
        , this, "isVisibleLoadMore");
        this.isCanLoadMore = false;
        this.isLoading = false;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.loadingDialog !== undefined) {
            this.loadingDialog = params.loadingDialog;
        }
        if (params.isShowLoadingDialog !== undefined) {
            this.isShowLoadingDialog = params.isShowLoadingDialog;
        }
        if (params.listNews !== undefined) {
            this.listNews = params.listNews;
        }
        if (params.tabType !== undefined) {
            this.tabType = params.tabType;
        }
        if (params.pageNo !== undefined) {
            this.pageNo = params.pageNo;
        }
        if (params.offsetY !== undefined) {
            this.offsetY = params.offsetY;
        }
        if (params.downY !== undefined) {
            this.downY = params.downY;
        }
        if (params.lastMoveY !== undefined) {
            this.lastMoveY = params.lastMoveY;
        }
        if (params.startIndex !== undefined) {
            this.startIndex = params.startIndex;
        }
        if (params.endIndex !== undefined) {
            this.endIndex = params.endIndex;
        }
        if (params.pullRefreshHeight !== undefined) {
            this.pullRefreshHeight = params.pullRefreshHeight;
        }
        if (params.pullRefreshText !== undefined) {
            this.pullRefreshText = params.pullRefreshText;
        }
        if (params.pullRefreshImage !== undefined) {
            this.pullRefreshImage = params.pullRefreshImage;
        }
        if (params.isCanRefresh !== undefined) {
            this.isCanRefresh = params.isCanRefresh;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
        if (params.isPullRefreshOperation !== undefined) {
            this.isPullRefreshOperation = params.isPullRefreshOperation;
        }
        if (params.loadMoreHeight !== undefined) {
            this.loadMoreHeight = params.loadMoreHeight;
        }
        if (params.isVisibleLoadMore !== undefined) {
            this.isVisibleLoadMore = params.isVisibleLoadMore;
        }
        if (params.isCanLoadMore !== undefined) {
            this.isCanLoadMore = params.isCanLoadMore;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__listNews.purgeDependencyOnElmtId(rmElmtId);
        this.__offsetY.purgeDependencyOnElmtId(rmElmtId);
        this.__pullRefreshText.purgeDependencyOnElmtId(rmElmtId);
        this.__pullRefreshImage.purgeDependencyOnElmtId(rmElmtId);
        this.__isVisibleLoadMore.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__listNews.aboutToBeDeleted();
        this.__offsetY.aboutToBeDeleted();
        this.__pullRefreshText.aboutToBeDeleted();
        this.__pullRefreshImage.aboutToBeDeleted();
        this.__isVisibleLoadMore.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get listNews() {
        return this.__listNews.get();
    }
    set listNews(newValue) {
        this.__listNews.set(newValue);
    }
    get offsetY() {
        return this.__offsetY.get();
    }
    set offsetY(newValue) {
        this.__offsetY.set(newValue);
    }
    get pullRefreshText() {
        return this.__pullRefreshText.get();
    }
    set pullRefreshText(newValue) {
        this.__pullRefreshText.set(newValue);
    }
    get pullRefreshImage() {
        return this.__pullRefreshImage.get();
    }
    set pullRefreshImage(newValue) {
        this.__pullRefreshImage.set(newValue);
    }
    get isVisibleLoadMore() {
        return this.__isVisibleLoadMore.get();
    }
    set isVisibleLoadMore(newValue) {
        this.__isVisibleLoadMore.set(newValue);
    }
    getHomeData() {
        if (this.isShowLoadingDialog) {
            // 显示加载框
            this.loadingDialog.open();
        }
        // 创建http
        let httpRequest = http.createHttp();
        // 请求数据
        httpRequest.request('http://v.juhe.cn/toutiao/index', {
            // 看源码得知method的类型为：RequestMethod
            // 但是设置 method: http.RequestMethod.POST 报错
            // 设置成 method: http.POST 可以
            // @ts-ignore
            method: http.POST,
            extraData: {
                'key': '9099932a8e3acd3dbdd4bd11fcc98738',
                'page_size': '10',
                'page': '' + this.pageNo,
                'type': '' + this.tabType,
            }
        }, (err, data) => {
            if (!err) {
                if (data.responseCode == 200) {
                    // 解析数据
                    var newsModel = JSON.parse(JSON.stringify(data.result));
                    // 判断接口返回码，0成功
                    if (newsModel.error_code == 0) {
                        if (this.pageNo == 1) {
                            this.listNews = newsModel.result.data;
                        }
                        else {
                            for (var i = 0; i < newsModel.result.data.length; i++) {
                                let newsData = newsModel.result.data[i];
                                this.listNews.push(newsData);
                            }
                        }
                    }
                    else {
                        // 接口异常，弹出提示
                        prompt.showToast({ message: newsModel.reason });
                    }
                }
                else {
                    // 请求失败，弹出提示
                    prompt.showToast({ message: '网络异常' });
                }
            }
            else {
                // 请求失败，弹出提示
                prompt.showToast({ message: err.message });
            }
            if (this.isShowLoadingDialog) {
                // 关闭加载框
                setTimeout(() => {
                    this.loadingDialog.close();
                }, 500);
            }
            // 关闭下拉刷新
            if (this.isRefreshing) {
                this.closeRefresh();
            }
            // 关闭加载更多
            if (this.isLoading) {
                this.closeLoadMore();
            }
            this.isShowLoadingDialog = true;
        });
    }
    // 自定义下拉刷新布局
    CustomPullRefreshLayout(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Flex.create({ justifyContent: FlexAlign.Center, alignItems: ItemAlign.Center });
            Flex.debugLine("pages/customCpt/home.ets(129:5)");
            Flex.width('100%');
            Flex.height(this.pullRefreshHeight);
            Flex.offset({ x: 0, y: `${vp2px(-this.pullRefreshHeight) + this.offsetY}px` });
            if (!isInitialRender) {
                Flex.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.pullRefreshImage);
            Image.debugLine("pages/customCpt/home.ets(130:7)");
            Image.width(18);
            Image.height(18);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.pullRefreshText);
            Text.debugLine("pages/customCpt/home.ets(134:7)");
            Text.margin({ left: 7, bottom: 1 });
            Text.fontSize(17);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Flex.pop();
    }
    // 自定义加载更多布局
    CustomLoadMoreLayout(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Flex.create({ justifyContent: FlexAlign.Center, alignItems: ItemAlign.Center });
            Flex.debugLine("pages/customCpt/home.ets(146:5)");
            Flex.width('100%');
            Flex.height(this.loadMoreHeight);
            Flex.backgroundColor('#f4f4f4');
            Flex.visibility(this.isVisibleLoadMore ? Visibility.Visible : Visibility.None);
            if (!isInitialRender) {
                Flex.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777254, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
            Image.debugLine("pages/customCpt/home.ets(147:7)");
            Image.width(18);
            Image.height(18);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('加载更多中...');
            Text.debugLine("pages/customCpt/home.ets(151:7)");
            Text.margin({ left: 7, bottom: 1 });
            Text.fontSize(17);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Flex.pop();
    }
    // 单个图片样式
    ItemSinglePic(item, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/customCpt/home.ets(163:5)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/customCpt/home.ets(164:7)");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
            Column.height(80);
            Column.padding({ top: 3, bottom: 3, right: 5 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(item.title);
            Text.debugLine("pages/customCpt/home.ets(165:9)");
            Text.fontSize(14);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/customCpt/home.ets(170:9)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 10 });
            Row.debugLine("pages/customCpt/home.ets(172:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(item.author_name);
            Text.debugLine("pages/customCpt/home.ets(173:11)");
            Text.fontSize(12);
            Text.fontColor(Color.Gray);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(item.date);
            Text.debugLine("pages/customCpt/home.ets(177:11)");
            Text.fontSize(12);
            Text.fontColor(Color.Gray);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(item.thumbnail_pic_s);
            Image.debugLine("pages/customCpt/home.ets(187:7)");
            Image.width(110);
            Image.height(80);
            Image.padding('1px');
            Image.borderRadius(5);
            Image.borderWidth(1);
            Image.borderColor('#e6e6e6');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
    }
    // 多个图片样式
    ItemMorePic(item, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/customCpt/home.ets(199:5)");
            Column.alignItems(HorizontalAlign.Start);
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(item.title);
            Text.debugLine("pages/customCpt/home.ets(200:7)");
            Text.fontSize(14);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 2 });
            Row.debugLine("pages/customCpt/home.ets(205:7)");
            Row.margin({ top: 3 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(item.thumbnail_pic_s);
            Image.debugLine("pages/customCpt/home.ets(206:9)");
            Image.width(110);
            Image.height(80);
            Image.padding('1px');
            Image.borderRadius(5);
            Image.borderWidth(1);
            Image.borderColor('#e6e6e6');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (item.thumbnail_pic_s02 != undefined) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create(item.thumbnail_pic_s02);
                        Image.debugLine("pages/customCpt/home.ets(215:11)");
                        Image.width(110);
                        Image.height(80);
                        Image.padding('1px');
                        Image.borderRadius(5);
                        Image.borderWidth(1);
                        Image.borderColor('#e6e6e6');
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (item.thumbnail_pic_s03 != undefined) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create(item.thumbnail_pic_s03);
                        Image.debugLine("pages/customCpt/home.ets(225:11)");
                        Image.width(110);
                        Image.height(80);
                        Image.padding('1px');
                        Image.borderRadius(5);
                        Image.borderWidth(1);
                        Image.borderColor('#e6e6e6');
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 10 });
            Row.debugLine("pages/customCpt/home.ets(236:7)");
            Row.margin({ top: 3 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(item.author_name);
            Text.debugLine("pages/customCpt/home.ets(237:9)");
            Text.fontSize(12);
            Text.fontColor(Color.Gray);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(item.date);
            Text.debugLine("pages/customCpt/home.ets(241:9)");
            Text.fontSize(12);
            Text.fontColor(Color.Gray);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
    }
    // 刷新测试数据
    refreshData() {
        this.isShowLoadingDialog = false;
        this.pageNo = 1;
        // this.getHomeData()
        this.listNews = getTest();
        this.closeRefresh();
    }
    // 加载更多测试数据
    loadMoreData() {
        this.isShowLoadingDialog = false;
        this.pageNo++;
        this.getHomeData();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/customCpt/home.ets(267:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#f4f4f4');
            Column.onAppear(() => {
                this.refreshData();
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Flex.create();
            Flex.debugLine("pages/customCpt/home.ets(268:7)");
            if (!isInitialRender) {
                Flex.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new HomeTabs(this, { tabClick: (item) => {
                            this.tabType = item.tabType;
                            this.pageNo = 1;
                            this.getHomeData();
                        } }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        Flex.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/customCpt/home.ets(276:7)");
            Column.width('100%');
            Column.height('95%');
            Column.zIndex(-1);
            Column.onTouch((event) => this.listTouchEvent(event));
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 下拉刷新布局
        this.CustomPullRefreshLayout.bind(this)();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 列表布局
            List.create();
            List.debugLine("pages/customCpt/home.ets(281:9)");
            // 列表布局
            List.backgroundColor(Color.White);
            // 列表布局
            List.divider({ color: '#f5f5f5', strokeWidth: 1 });
            // 列表布局
            List.edgeEffect(EdgeEffect.None);
            // 列表布局
            List.offset({ x: 0, y: `${this.offsetY}px` });
            // 列表布局
            List.onScrollIndex((start, end) => {
                console.info(`${start}=start============end=${end}`);
                this.startIndex = start;
                this.endIndex = end;
            });
            if (!isInitialRender) {
                // 列表布局
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.padding(10);
                        ListItem.debugLine("pages/customCpt/home.ets(283:13)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/customCpt/home.ets(284:15)");
                            Column.width('100%');
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            if (item.thumbnail_pic_s02 == undefined) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.ItemSinglePic.bind(this)(item);
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    this.ItemMorePic.bind(this)(item);
                                });
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/customCpt/home.ets(284:15)");
                            Column.width('100%');
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            if (item.thumbnail_pic_s02 == undefined) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.ItemSinglePic.bind(this)(item);
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    this.ItemMorePic.bind(this)(item);
                                });
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.listNews, forEachItemGenFunction, item => item.uniquekey, false, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.debugLine("pages/customCpt/home.ets(295:11)");
                if (!isInitialRender) {
                    // 加载更多布局
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                // 加载更多布局
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.CustomLoadMoreLayout.bind(this)();
                // 加载更多布局
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.CustomLoadMoreLayout.bind(this)();
                // 加载更多布局
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        // 列表布局
        List.pop();
        Column.pop();
        Column.pop();
    }
    // 触摸事件
    listTouchEvent(event) {
        switch (event.type) {
            case TouchType.Down: // 手指按下
                // 记录按下的y坐标
                this.downY = event.touches[0].y;
                this.lastMoveY = event.touches[0].y;
                break;
            case TouchType.Move: // 手指移动
                // 下拉刷新中 或 加载更多中，不进入处理逻辑
                if (this.isRefreshing || this.isLoading) {
                    console.info('========Move刷新中，返回=========');
                    return;
                }
                // 判断手势
                let isDownPull = event.touches[0].y - this.lastMoveY > 0;
                // 下拉手势 或 已经进入了下拉刷新操作
                if ((isDownPull || this.isPullRefreshOperation) && !this.isCanLoadMore) {
                    this.touchMovePullRefresh(event);
                }
                else {
                    this.touchMoveLoadMore(event);
                }
                this.lastMoveY = event.touches[0].y;
                break;
            case TouchType.Up: // 手指抬起
            case TouchType.Cancel: // 触摸意外中断：来电界面
                // 刷新中 或 加载更多中，不进入处理逻辑
                if (this.isRefreshing || this.isLoading) {
                    console.info('========Up刷新中，返回=========');
                    return;
                }
                if (this.isPullRefreshOperation) {
                    this.touchUpPullRefresh();
                }
                else {
                    this.touchUpLoadMore();
                }
                break;
        }
    }
    //============================================下拉刷新==================================================
    // 手指移动，处理下拉刷新
    touchMovePullRefresh(event) {
        // 当首部索引位于0
        if (this.startIndex == 0) {
            this.isPullRefreshOperation = true;
            // 下拉刷新布局高度
            var height = vp2px(this.pullRefreshHeight);
            // 滑动的偏移量
            this.offsetY = event.touches[0].y - this.downY;
            // 偏移量大于下拉刷新布局高度，达到刷新条件
            if (this.offsetY >= height) {
                // 状态1：松开刷新
                this.pullRefreshState(1);
                // 偏移量的值缓慢增加
                this.offsetY = height + this.offsetY * 0.15;
            }
            else {
                // 状态0：下拉刷新
                this.pullRefreshState(0);
            }
            if (this.offsetY < 0) {
                this.offsetY = 0;
                this.isPullRefreshOperation = false;
            }
        }
    }
    // 手指抬起，处理下拉刷新
    touchUpPullRefresh() {
        // 是否可以刷新
        if (this.isCanRefresh) {
            console.info('======执行下拉刷新========');
            // 偏移量为下拉刷新布局高度
            this.offsetY = vp2px(this.pullRefreshHeight);
            // 状态2：正在刷新
            this.pullRefreshState(2);
            // 耗时操作
            this.refreshData();
        }
        else {
            console.info('======关闭下拉刷新！未达到条件========');
            // 关闭刷新
            this.closeRefresh();
        }
    }
    // 下拉刷新状态
    // 0下拉刷新、1松开刷新、2正在刷新、3刷新成功
    pullRefreshState(state) {
        switch (state) {
            case 0:
                // 初始状态
                this.pullRefreshText = '下拉刷新';
                this.pullRefreshImage = { "id": 16777230, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" };
                this.isCanRefresh = false;
                this.isRefreshing = false;
                break;
            case 1:
                this.pullRefreshText = '松开刷新';
                this.pullRefreshImage = { "id": 16777288, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" };
                this.isCanRefresh = true;
                this.isRefreshing = false;
                break;
            case 2:
                this.offsetY = vp2px(this.pullRefreshHeight);
                this.pullRefreshText = '正在刷新';
                this.pullRefreshImage = { "id": 16777254, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" };
                this.isCanRefresh = true;
                this.isRefreshing = true;
                break;
            case 3:
                this.pullRefreshText = '刷新成功';
                this.pullRefreshImage = { "id": 16777289, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" };
                this.isCanRefresh = true;
                this.isRefreshing = true;
                break;
        }
    }
    // 关闭刷新
    closeRefresh() {
        // 如果允许刷新，延迟进入，为了显示刷新中
        setTimeout(() => {
            var delay = 50;
            if (this.isCanRefresh) {
                // 状态3：刷新成功
                this.pullRefreshState(3);
                // 为了显示刷新成功，延迟执行收缩动画
                delay = 500;
            }
            Context.animateTo({
                duration: 150,
                delay: delay,
                onFinish: () => {
                    // 状态0：下拉刷新
                    this.pullRefreshState(0);
                    this.isPullRefreshOperation = false;
                }
            }, () => {
                this.offsetY = 0;
            });
        }, this.isCanRefresh ? 500 : 0);
    }
    //============================================加载更多==================================================
    // 手指移动，处理加载更多
    touchMoveLoadMore(event) {
        // 因为加载更多是在列表后面新增一个item，当一屏能够展示全部列表，endIndex 为 length+1
        if (this.endIndex == this.listNews.length - 1 || this.endIndex == this.listNews.length) {
            // 滑动的偏移量
            this.offsetY = event.touches[0].y - this.downY;
            if (Math.abs(this.offsetY) > vp2px(this.loadMoreHeight) / 2) {
                // 可以刷新了
                this.isCanLoadMore = true;
                // 显示加载更多布局
                this.isVisibleLoadMore = true;
                // 偏移量缓慢增加
                this.offsetY = -vp2px(this.loadMoreHeight) + this.offsetY * 0.1;
            }
        }
    }
    // 手指抬起，处理加载更多
    touchUpLoadMore() {
        Context.animateTo({
            duration: 200, // 动画时长
        }, () => {
            // 偏移量设置为0
            this.offsetY = 0;
        });
        if (this.isCanLoadMore) {
            console.info('======执行加载更多========');
            // 加载中...
            this.isLoading = true;
            // 耗时操作
            this.loadMoreData();
        }
        else {
            console.info('======关闭加载更多！未达到条件========');
            this.closeLoadMore();
        }
    }
    // 关闭加载更多
    closeLoadMore() {
        this.isCanLoadMore = false;
        this.isLoading = false;
        this.isVisibleLoadMore = false;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new HomePage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=home.js.map