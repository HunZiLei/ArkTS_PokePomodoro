import promptAction from '@ohos:promptAction';
import CommonConstants from '@bundle:top.handwer.homeworktasklist/entry/ets/common/constants/CommonConsts';
import Logger from '@bundle:top.handwer.homeworktasklist/entry/ets/common/utils/Logger';
export class TaskItemDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__taskItem = new SynchedPropertyObjectTwoWayPU(params.taskItem, this, "taskItem");
        this.__dialogIsAddNew = new SynchedPropertySimpleTwoWayPU(params.dialogIsAddNew, this, "dialogIsAddNew");
        this.controller = undefined;
        this.confirm = undefined;
        this.color_column = '#99DBBA';
        this.color_back = '#A1E6C2';
        this.color_button = '#4BAD96';
        this.taskName = undefined;
        this.taskSubject = undefined;
        this.taskDate = undefined;
        this.taskDetailText = undefined;
        this.taskDdlDetail = '0.3-0.5-0.9';
        this.__showedTaskDate = new ObservedPropertySimplePU('', this, "showedTaskDate");
        this.__showedTaskTime = new ObservedPropertySimplePU('', this, "showedTaskTime");
        this.__showedTaskDDL = new ObservedPropertySimplePU('正常', this, "showedTaskDDL");
        this.__handlePopup = new ObservedPropertySimplePU(false, this, "handlePopup");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.confirm !== undefined) {
            this.confirm = params.confirm;
        }
        if (params.color_column !== undefined) {
            this.color_column = params.color_column;
        }
        if (params.color_back !== undefined) {
            this.color_back = params.color_back;
        }
        if (params.color_button !== undefined) {
            this.color_button = params.color_button;
        }
        if (params.taskName !== undefined) {
            this.taskName = params.taskName;
        }
        if (params.taskSubject !== undefined) {
            this.taskSubject = params.taskSubject;
        }
        if (params.taskDate !== undefined) {
            this.taskDate = params.taskDate;
        }
        if (params.taskDetailText !== undefined) {
            this.taskDetailText = params.taskDetailText;
        }
        if (params.taskDdlDetail !== undefined) {
            this.taskDdlDetail = params.taskDdlDetail;
        }
        if (params.showedTaskDate !== undefined) {
            this.showedTaskDate = params.showedTaskDate;
        }
        if (params.showedTaskTime !== undefined) {
            this.showedTaskTime = params.showedTaskTime;
        }
        if (params.showedTaskDDL !== undefined) {
            this.showedTaskDDL = params.showedTaskDDL;
        }
        if (params.handlePopup !== undefined) {
            this.handlePopup = params.handlePopup;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__taskItem.purgeDependencyOnElmtId(rmElmtId);
        this.__dialogIsAddNew.purgeDependencyOnElmtId(rmElmtId);
        this.__showedTaskDate.purgeDependencyOnElmtId(rmElmtId);
        this.__showedTaskTime.purgeDependencyOnElmtId(rmElmtId);
        this.__showedTaskDDL.purgeDependencyOnElmtId(rmElmtId);
        this.__handlePopup.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__taskItem.aboutToBeDeleted();
        this.__dialogIsAddNew.aboutToBeDeleted();
        this.__showedTaskDate.aboutToBeDeleted();
        this.__showedTaskTime.aboutToBeDeleted();
        this.__showedTaskDDL.aboutToBeDeleted();
        this.__handlePopup.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get taskItem() {
        return this.__taskItem.get();
    }
    set taskItem(newValue) {
        this.__taskItem.set(newValue);
    }
    get dialogIsAddNew() {
        return this.__dialogIsAddNew.get();
    }
    set dialogIsAddNew(newValue) {
        this.__dialogIsAddNew.set(newValue);
    }
    setController(ctr) {
        this.controller = ctr;
    }
    get showedTaskDate() {
        return this.__showedTaskDate.get();
    }
    set showedTaskDate(newValue) {
        this.__showedTaskDate.set(newValue);
    }
    get showedTaskTime() {
        return this.__showedTaskTime.get();
    }
    set showedTaskTime(newValue) {
        this.__showedTaskTime.set(newValue);
    }
    get showedTaskDDL() {
        return this.__showedTaskDDL.get();
    }
    set showedTaskDDL(newValue) {
        this.__showedTaskDDL.set(newValue);
    }
    get handlePopup() {
        return this.__handlePopup.get();
    }
    set handlePopup(newValue) {
        this.__handlePopup.set(newValue);
    }
    DatePickerMenu(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Menu.create();
            Menu.debugLine("view/TaskItemDialog.ets(29:5)");
            if (!isInitialRender) {
                Menu.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            MenuItem.create();
            MenuItem.debugLine("view/TaskItemDialog.ets(30:7)");
            if (!isInitialRender) {
                MenuItem.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            DatePicker.create({
                start: new Date('1970-01-01'),
                selected: this.taskDate,
                end: new Date('2100-01-01')
            });
            DatePicker.debugLine("view/TaskItemDialog.ets(31:9)");
            DatePicker.onChange((value) => {
                Logger.debug(`TaskItemDialog date = ${JSON.stringify(value)}`);
                this.taskDate.setFullYear(value.year, value.month, value.day);
                Logger.debug(`TaskItemDialog res = ${JSON.stringify(this.taskDate)}, str = ${this.taskDate.toLocaleString()}`);
                this.showedTaskDate = getDateString(this.taskDate.getTime());
            });
            DatePicker.backgroundColor(0xffffff);
            if (!isInitialRender) {
                DatePicker.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        DatePicker.pop();
        MenuItem.pop();
        Menu.pop();
    }
    TimePickerMenu(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Menu.create();
            Menu.debugLine("view/TaskItemDialog.ets(47:5)");
            if (!isInitialRender) {
                Menu.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            MenuItem.create();
            MenuItem.debugLine("view/TaskItemDialog.ets(48:7)");
            if (!isInitialRender) {
                MenuItem.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TimePicker.create({
                // start: new Date('1970-01-01'),
                selected: this.taskDate,
                // end: new Date('2100-01-01')
            });
            TimePicker.debugLine("view/TaskItemDialog.ets(49:9)");
            TimePicker.onChange((value) => {
                Logger.debug(`TaskItemDialog date = ${JSON.stringify(value)}`);
                this.taskDate.setHours(value.hour, value.minute);
                Logger.debug(`TaskItemDialog res = ${JSON.stringify(this.taskDate)}, str = ${this.taskDate.toLocaleString()}`);
                this.showedTaskTime = getTimeString(this.taskDate.getTime());
            });
            TimePicker.backgroundColor(0xffffff);
            TimePicker.width('80%');
            if (!isInitialRender) {
                TimePicker.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TimePicker.pop();
        MenuItem.pop();
        Menu.pop();
    }
    DDLDetailPickerMenu(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Menu.create();
            Menu.debugLine("view/TaskItemDialog.ets(66:5)");
            if (!isInitialRender) {
                Menu.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const preset = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    MenuItem.create({ content: preset.hint });
                    MenuItem.debugLine("view/TaskItemDialog.ets(68:9)");
                    MenuItem.onClick(() => {
                        this.taskDdlDetail = preset.detail;
                        this.showedTaskDDL = preset.hint;
                    });
                    if (!isInitialRender) {
                        MenuItem.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                MenuItem.pop();
            };
            this.forEachUpdateFunction(elmtId, CommonConstants.DDL_DETAIL_PRESET, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Menu.pop();
    }
    aboutToAppear() {
        this.taskName = this.taskItem.task_name;
        this.taskSubject = this.taskItem.subject;
        this.taskDetailText = this.taskItem.detail;
        this.taskDdlDetail = this.taskItem.ddl_detail;
        this.taskDate = new Date();
        this.taskDate.setSeconds(0);
        Logger.debug('TaskItemDialog new date = ' + this.taskDate.toLocaleString());
        if (this.taskItem.due_date_stamp)
            this.taskDate.setTime(this.taskItem.due_date_stamp);
        this.showedTaskDate = getDateString(this.taskDate.getTime());
        this.showedTaskTime = getTimeString(this.taskDate.getTime());
        this.showedTaskDDL = getDDLPresetFromDetail(this.taskDdlDetail);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/TaskItemDialog.ets(93:5)");
            Column.backgroundColor(this.color_back);
            Column.width('100%');
            Column.height('60%');
            Column.borderRadius(24);
            Column.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777232, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
            Image.debugLine("view/TaskItemDialog.ets(94:7)");
            Image.width(64);
            Image.height(24);
            Image.onClick(() => {
                var _a;
                (_a = this.controller) === null || _a === void 0 ? void 0 : _a.close();
            });
            Image.margin({ top: 5 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/TaskItemDialog.ets(101:7)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/TaskItemDialog.ets(102:9)");
            Column.padding({ left: 16, right: 16 });
            Column.margin({ bottom: 20 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create((this.dialogIsAddNew ? '添加' : '修改') + '事项');
            Text.debugLine("view/TaskItemDialog.ets(103:11)");
            Text.fontSize(20);
            Text.alignSelf(ItemAlign.Start);
            Text.margin({ left: 12, bottom: 20 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: '事件名称',
                text: this.taskName
            });
            TextInput.debugLine("view/TaskItemDialog.ets(108:11)");
            TextInput.onChange((value) => {
                this.taskName = value;
            });
            TextInput.backgroundColor(this.color_column);
            TextInput.margin({ bottom: 10 });
            TextInput.height(50);
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // TextInput({
            //   placeholder: '作业科目',
            //   text: this.taskSubject == 0 ? '' : this.taskSubject.toString()
            // })
            //   .backgroundColor(0xf1f2f3)
            //   .height(50)
            //   .margin({ bottom: 20 })
            //   .onChange((value: string) => {
            //     this.taskSubject = Number(value)
            //   })
            TextArea.create({ placeholder: '详细信息', text: this.taskDetailText });
            TextArea.debugLine("view/TaskItemDialog.ets(128:11)");
            // TextInput({
            //   placeholder: '作业科目',
            //   text: this.taskSubject == 0 ? '' : this.taskSubject.toString()
            // })
            //   .backgroundColor(0xf1f2f3)
            //   .height(50)
            //   .margin({ bottom: 20 })
            //   .onChange((value: string) => {
            //     this.taskSubject = Number(value)
            //   })
            TextArea.onChange((value) => {
                this.taskDetailText = value;
            });
            // TextInput({
            //   placeholder: '作业科目',
            //   text: this.taskSubject == 0 ? '' : this.taskSubject.toString()
            // })
            //   .backgroundColor(0xf1f2f3)
            //   .height(50)
            //   .margin({ bottom: 20 })
            //   .onChange((value: string) => {
            //     this.taskSubject = Number(value)
            //   })
            TextArea.height(50 * 3);
            // TextInput({
            //   placeholder: '作业科目',
            //   text: this.taskSubject == 0 ? '' : this.taskSubject.toString()
            // })
            //   .backgroundColor(0xf1f2f3)
            //   .height(50)
            //   .margin({ bottom: 20 })
            //   .onChange((value: string) => {
            //     this.taskSubject = Number(value)
            //   })
            TextArea.margin({ bottom: 10 });
            if (!isInitialRender) {
                // TextInput({
                //   placeholder: '作业科目',
                //   text: this.taskSubject == 0 ? '' : this.taskSubject.toString()
                // })
                //   .backgroundColor(0xf1f2f3)
                //   .height(50)
                //   .margin({ bottom: 20 })
                //   .onChange((value: string) => {
                //     this.taskSubject = Number(value)
                //   })
                TextArea.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/TaskItemDialog.ets(134:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // Text('自定义时间比例')
            //   .margin({right: 5})
            // TextInput({text: this.taskDdlDetail, placeholder: '默认为 0.3-0.5-0.9'})
            //   .onChange((value: string) => {
            //     this.taskDdlDetail = value
            //   })
            //   .width('60%')
            Button.createWithLabel('任务紧急程度：' + this.showedTaskDDL);
            Button.debugLine("view/TaskItemDialog.ets(142:13)");
            // Text('自定义时间比例')
            //   .margin({right: 5})
            // TextInput({text: this.taskDdlDetail, placeholder: '默认为 0.3-0.5-0.9'})
            //   .onChange((value: string) => {
            //     this.taskDdlDetail = value
            //   })
            //   .width('60%')
            Button.bindMenu({ builder: this.DDLDetailPickerMenu.bind(this) });
            // Text('自定义时间比例')
            //   .margin({right: 5})
            // TextInput({text: this.taskDdlDetail, placeholder: '默认为 0.3-0.5-0.9'})
            //   .onChange((value: string) => {
            //     this.taskDdlDetail = value
            //   })
            //   .width('60%')
            Button.width('60%');
            // Text('自定义时间比例')
            //   .margin({right: 5})
            // TextInput({text: this.taskDdlDetail, placeholder: '默认为 0.3-0.5-0.9'})
            //   .onChange((value: string) => {
            //     this.taskDdlDetail = value
            //   })
            //   .width('60%')
            Button.margin({ right: 15 });
            // Text('自定义时间比例')
            //   .margin({right: 5})
            // TextInput({text: this.taskDdlDetail, placeholder: '默认为 0.3-0.5-0.9'})
            //   .onChange((value: string) => {
            //     this.taskDdlDetail = value
            //   })
            //   .width('60%')
            Button.backgroundColor(this.color_column);
            // Text('自定义时间比例')
            //   .margin({right: 5})
            // TextInput({text: this.taskDdlDetail, placeholder: '默认为 0.3-0.5-0.9'})
            //   .onChange((value: string) => {
            //     this.taskDdlDetail = value
            //   })
            //   .width('60%')
            Button.fontColor('#000000');
            if (!isInitialRender) {
                // Text('自定义时间比例')
                //   .margin({right: 5})
                // TextInput({text: this.taskDdlDetail, placeholder: '默认为 0.3-0.5-0.9'})
                //   .onChange((value: string) => {
                //     this.taskDdlDetail = value
                //   })
                //   .width('60%')
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // Text('自定义时间比例')
        //   .margin({right: 5})
        // TextInput({text: this.taskDdlDetail, placeholder: '默认为 0.3-0.5-0.9'})
        //   .onChange((value: string) => {
        //     this.taskDdlDetail = value
        //   })
        //   .width('60%')
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle });
            Button.debugLine("view/TaskItemDialog.ets(148:13)");
            Button.onClick(() => { this.handlePopup = !this.handlePopup; });
            Button.height(25);
            Button.width(25);
            Button.backgroundColor('#ffffff');
            Button.bindPopup(this.handlePopup, {
                message: '任务紧急程度会决定指示颜色变化的快慢，任务紧急程度越高，指示颜色越早变红。',
                placementOnTop: true,
                primaryButton: {
                    value: '明白了',
                    action: () => { this.handlePopup = false; }
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777268, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
            Image.debugLine("view/TaskItemDialog.ets(149:15)");
            Image.height(25);
            Image.width(25);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/TaskItemDialog.ets(169:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('截止日期：' + this.showedTaskDate);
            Button.debugLine("view/TaskItemDialog.ets(170:11)");
            Button.bindMenu({ builder: this.DatePickerMenu.bind(this) });
            Button.backgroundColor(this.color_column);
            Button.fontColor(0x000000);
            Button.margin({ right: 10 });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel(this.showedTaskTime);
            Button.debugLine("view/TaskItemDialog.ets(176:11)");
            Button.bindMenu({ builder: this.TimePickerMenu.bind(this) });
            Button.backgroundColor(this.color_column);
            Button.fontColor(0x000000);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // .margin({ bottom: 10 })
            Row.create();
            Row.debugLine("view/TaskItemDialog.ets(183:9)");
            // .margin({ bottom: 10 })
            Row.margin({ bottom: 20 });
            if (!isInitialRender) {
                // .margin({ bottom: 10 })
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('取消');
            Button.debugLine("view/TaskItemDialog.ets(184:11)");
            Button.backgroundColor(this.color_button);
            Button.margin({ right: 10 });
            Button.onClick(() => {
                this.controller.close();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('保存');
            Button.debugLine("view/TaskItemDialog.ets(190:11)");
            Button.backgroundColor(this.color_button);
            Button.onClick(() => {
                if (this.taskName == '') {
                    promptAction.showToast({ message: '任务名称不能为空' });
                    return;
                }
                this.taskItem.subject = this.taskSubject;
                this.taskItem.task_name = this.taskName;
                this.taskItem.detail = this.taskDetailText;
                this.taskItem.due_date_stamp = this.taskDate.getTime();
                if (this.dialogIsAddNew)
                    this.taskItem.start_date_stamp = new Date().getTime();
                this.taskItem.ddl_detail = this.taskDdlDetail;
                Logger.debug(`TaskItemDialog ddlDetail = ${this.taskItem.ddl_detail}`);
                // Logger.debug(`TaskItemDialog due_date(stamp): ${this.taskItem.due_date_stamp}, date: ${this.taskDate.toDateString()}`)
                this.confirm(this.dialogIsAddNew, ObservedObject.GetRawObject(this.taskItem));
                this.controller.close();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        // .margin({ bottom: 10 })
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function getTimeString(date_stamp) {
    let date = new Date();
    date.setTime(date_stamp);
    Logger.debug(`TaskList: datestamp = ${date_stamp}, time = ${date.toLocaleTimeString()}`);
    return date.toLocaleTimeString();
}
function getDateString(date_stamp) {
    let date = new Date();
    date.setTime(date_stamp);
    Logger.debug(`TaskList: datestamp = ${date_stamp}, date = ${date.toLocaleDateString()}`);
    let ds = date.toLocaleDateString().split('/');
    let res = `${ds[2]}/${ds[0]}/${ds[1]}`;
    return res;
}
function getDDLPresetFromDetail(detail) {
    for (let i = 0; i < 5; ++i) {
        Logger.debug('getDDL: ' + CommonConstants.DDL_DETAIL_PRESET[i].detail);
        if (CommonConstants.DDL_DETAIL_PRESET[i].detail == detail)
            return CommonConstants.DDL_DETAIL_PRESET[i].hint;
    }
    return '';
}
//# sourceMappingURL=TaskItemDialog.js.map