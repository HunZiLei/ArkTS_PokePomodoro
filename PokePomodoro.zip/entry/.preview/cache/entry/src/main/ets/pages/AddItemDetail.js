import router from '@ohos:router';
class AddItemDetail extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.add_task_name = undefined;
        this.add_task_subject = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.add_task_name !== undefined) {
            this.add_task_name = params.add_task_name;
        }
        if (params.add_task_subject !== undefined) {
            this.add_task_subject = params.add_task_subject;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Navigation.create();
            Navigation.debugLine("pages/AddItemDetail.ets(12:5)");
            Navigation.titleMode(NavigationTitleMode.Mini);
            Navigation.title('添加任务');
            if (!isInitialRender) {
                Navigation.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '任务名称' });
            TextInput.debugLine("pages/AddItemDetail.ets(13:7)");
            TextInput.onChange((value) => {
                this.add_task_name = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '所属科目' });
            TextInput.debugLine("pages/AddItemDetail.ets(17:7)");
            TextInput.onChange((value) => {
                this.add_task_subject = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('添加');
            Button.debugLine("pages/AddItemDetail.ets(21:7)");
            Button.onClick(() => {
                router.back({
                    url: 'pages/Index',
                    params: {
                        task_name: this.add_task_name,
                        task_subject: this.add_task_subject
                    }
                });
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Navigation.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new AddItemDetail(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=AddItemDetail.js.map