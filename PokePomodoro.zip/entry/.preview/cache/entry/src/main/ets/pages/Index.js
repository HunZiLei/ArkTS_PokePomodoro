import { Settings } from '@bundle:top.handwer.homeworktasklist/entry/ets/components/IndexTabPages/Settings';
import { TaskList } from '@bundle:top.handwer.homeworktasklist/entry/ets/components/IndexTabPages/TaskList';
import DDLState from '@bundle:top.handwer.homeworktasklist/entry/ets/components/IndexTabPages/DDLState';
import { Pomodoro } from '@bundle:top.handwer.homeworktasklist/entry/ets/components/IndexTabPages/Pomodoro';
import { GameManu } from '@bundle:top.handwer.homeworktasklist/entry/ets/components/IndexTabPages/GameMenu';
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.__colorStyle = new ObservedPropertySimplePU('blue', this, "colorStyle");
        this.controller = new TabsController();
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.colorStyle !== undefined) {
            this.colorStyle = params.colorStyle;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__colorStyle.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        this.__currentIndex.aboutToBeDeleted();
        this.__colorStyle.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue) {
        this.__currentIndex.set(newValue);
    }
    get colorStyle() {
        return this.__colorStyle.get();
    }
    set colorStyle(newValue) {
        this.__colorStyle.set(newValue);
    }
    //底边栏
    TabBuilder(title, targetIndex, selectedImg, normalImg, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(19:5)");
            Column.backgroundColor('#79AD92');
            Column.width('100%');
            Column.height(50);
            Column.justifyContent(FlexAlign.Center);
            Column.onClick(() => {
                this.currentIndex = targetIndex;
                this.controller.changeIndex(targetIndex);
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.currentIndex === targetIndex ? selectedImg : normalImg);
            Image.debugLine("pages/Index.ets(20:7)");
            Image.size({ width: 25, height: 25 });
            Image.fillColor(this.currentIndex === targetIndex ? '#47DEA9' : '#6B6B6B');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(title);
            Text.debugLine("pages/Index.ets(23:7)");
            Text.fontColor(this.currentIndex === targetIndex ? '#47DEA9' : '#6B6B6B');
            Text.fontSize(12);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    TabBuilder_string(title, targetIndex, selectedImg, normalImg, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(37:5)");
            Column.backgroundColor('#79AD92');
            Column.width('100%');
            Column.height(50);
            Column.justifyContent(FlexAlign.Center);
            Column.onClick(() => {
                this.currentIndex = targetIndex;
                this.controller.changeIndex(targetIndex);
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.currentIndex === targetIndex ? selectedImg : normalImg);
            Image.debugLine("pages/Index.ets(38:7)");
            Image.size({ width: 25, height: 25 });
            Image.fillColor(this.currentIndex === targetIndex ? '#47DEA9' : '#6B6B6B');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(title);
            Text.debugLine("pages/Index.ets(41:7)");
            Text.fontColor(this.currentIndex === targetIndex ? '#47DEA9' : '#6B6B6B');
            Text.fontSize(12);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(56:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundImage(this.currentIndex == 4 ? { "id": 16777231, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" } : { "id": 16777261, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
            Column.backgroundImageSize({ width: '100%', height: '100%' });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create({ barPosition: BarPosition.End, controller: this.controller });
            Tabs.debugLine("pages/Index.ets(57:7)");
            Tabs.onChange((index) => {
                this.currentIndex = index;
            });
            Tabs.scrollable(false);
            Tabs.animationDuration(100);
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new TaskList(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, { "id": 16777246, "type": 10003, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" }, 0, { "id": 16777252, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" }, { "id": 16777226, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
                } });
            TabContent.debugLine("pages/Index.ets(58:9)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new DDLState(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, { "id": 16777244, "type": 10003, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" }, 1, { "id": 16777266, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" }, { "id": 16777272, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
                } });
            TabContent.debugLine("pages/Index.ets(61:9)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new Settings(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, { "id": 16777242, "type": 10003, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" }, 2, { "id": 16777236, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" }, { "id": 16777222, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
                } });
            TabContent.debugLine("pages/Index.ets(64:9)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new Pomodoro(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, { "id": 16777245, "type": 10003, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" }, 3, { "id": 16777220, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" }, { "id": 16777220, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
                } });
            TabContent.debugLine("pages/Index.ets(67:9)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new GameManu(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder_string.call(this, "休息", 4, { "id": 16777281, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" }, { "id": 16777281, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
                } });
            TabContent.debugLine("pages/Index.ets(70:9)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        Tabs.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Index(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Index.js.map