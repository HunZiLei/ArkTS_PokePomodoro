export default class DDLDetailClass {
    constructor(hint, detail) {
        this.hint = hint;
        this.detail = detail;
    }
}
//# sourceMappingURL=DDLDetailClass.js.map