import TaskTable from '@bundle:top.handwer.homeworktasklist/entry/ets/common/database/TaskTable';
import TaskData from '@bundle:top.handwer.homeworktasklist/entry/ets/common/bean/TaskDataDefault';
import Logger from '@bundle:top.handwer.homeworktasklist/entry/ets/common/utils/Logger';
import { TaskItemDialog } from '@bundle:top.handwer.homeworktasklist/entry/ets/view/TaskItemDialog';
import { TaskItemDialog_ViewOnly } from '@bundle:top.handwer.homeworktasklist/entry/ets/view/TaskItemDialog_ViewOnly';
import promptAction from '@ohos:promptAction';
import CommonConstants from '@bundle:top.handwer.homeworktasklist/entry/ets/common/constants/CommonConsts';
export class TaskList extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__tasks = new ObservedPropertyObjectPU([], this, "tasks");
        this.__isEditing = new ObservedPropertySimplePU(false
        // @State isOnSearch: boolean = false
        , this, "isEditing");
        this.__dialogIsAddNew = new ObservedPropertySimplePU(true, this, "dialogIsAddNew");
        this.__taskItem = new ObservedPropertyObjectPU(new TaskData()
        // private isDetailAdd: boolean = false
        , this, "taskItem");
        this.firstOpen = true;
        this.taskTable = new TaskTable(() => { });
        this.dialogSelectedIndex = -1;
        this.deleteTarget = [];
        this.dialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new TaskItemDialog(this, {
                    dialogIsAddNew: this.__dialogIsAddNew,
                    taskItem: this.__taskItem,
                    confirm: (dialogIsAddNew, taskItem) => {
                        if (dialogIsAddNew) {
                            this.submitNewTask(taskItem);
                        }
                        else {
                            this.updateExistingTask(taskItem);
                        }
                        dialogIsAddNew = true;
                    }
                });
                jsDialog.setController(this.
                // UI 编辑弹窗 Dialog
                dialogController);
                ViewPU.create(jsDialog);
            },
            alignment: DialogAlignment.Bottom,
            customStyle: true
        }, this);
        this.dialogController_view = new CustomDialogController({
            builder: () => {
                let jsDialog = new TaskItemDialog_ViewOnly(this, {
                    taskItem: this.__taskItem
                });
                jsDialog.setController(this.dialogController_view);
                ViewPU.create(jsDialog);
            },
            alignment: DialogAlignment.Bottom,
            customStyle: true
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.tasks !== undefined) {
            this.tasks = params.tasks;
        }
        if (params.isEditing !== undefined) {
            this.isEditing = params.isEditing;
        }
        if (params.dialogIsAddNew !== undefined) {
            this.dialogIsAddNew = params.dialogIsAddNew;
        }
        if (params.taskItem !== undefined) {
            this.taskItem = params.taskItem;
        }
        if (params.firstOpen !== undefined) {
            this.firstOpen = params.firstOpen;
        }
        if (params.taskTable !== undefined) {
            this.taskTable = params.taskTable;
        }
        if (params.dialogSelectedIndex !== undefined) {
            this.dialogSelectedIndex = params.dialogSelectedIndex;
        }
        if (params.deleteTarget !== undefined) {
            this.deleteTarget = params.deleteTarget;
        }
        if (params.dialogController !== undefined) {
            this.dialogController = params.dialogController;
        }
        if (params.dialogController_view !== undefined) {
            this.dialogController_view = params.dialogController_view;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__tasks.purgeDependencyOnElmtId(rmElmtId);
        this.__isEditing.purgeDependencyOnElmtId(rmElmtId);
        this.__dialogIsAddNew.purgeDependencyOnElmtId(rmElmtId);
        this.__taskItem.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__tasks.aboutToBeDeleted();
        this.__isEditing.aboutToBeDeleted();
        this.__dialogIsAddNew.aboutToBeDeleted();
        this.__taskItem.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get tasks() {
        return this.__tasks.get();
    }
    set tasks(newValue) {
        this.__tasks.set(newValue);
    }
    get isEditing() {
        return this.__isEditing.get();
    }
    set isEditing(newValue) {
        this.__isEditing.set(newValue);
    }
    get dialogIsAddNew() {
        return this.__dialogIsAddNew.get();
    }
    set dialogIsAddNew(newValue) {
        this.__dialogIsAddNew.set(newValue);
    }
    get taskItem() {
        return this.__taskItem.get();
    }
    set taskItem(newValue) {
        this.__taskItem.set(newValue);
    }
    // UI ListItemGroup Header
    listItemGroupHead(text, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(text);
            Text.debugLine("components/IndexTabPages/TaskList.ets(52:5)");
            Text.margin(10);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
    }
    TaskList_ListItem(item, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/IndexTabPages/TaskList.ets(57:7)");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.height(56);
            Row.width('100%');
            Row.padding({ left: 12, right: 12 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (!this.isEditing) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Checkbox.create();
                        Checkbox.debugLine("components/IndexTabPages/TaskList.ets(59:11)");
                        Checkbox.select(item.is_completed);
                        Checkbox.onChange((value) => {
                            item.is_completed = value;
                            this.updateExistingTask(item);
                        });
                        Checkbox.margin({ right: 10 });
                        if (!isInitialRender) {
                            Checkbox.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Checkbox.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(item.task_name);
            Text.debugLine("components/IndexTabPages/TaskList.ets(67:9)");
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.maxLines(1);
            Text.width('60%');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("components/IndexTabPages/TaskList.ets(71:9)");
            Blank.layoutWeight(1);
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/IndexTabPages/TaskList.ets(73:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(getTimeString(item.due_date_stamp));
            Text.debugLine("components/IndexTabPages/TaskList.ets(74:11)");
            Text.margin({ right: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (!item.is_completed) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithChild({ type: ButtonType.Circle, });
                        Button.debugLine("components/IndexTabPages/TaskList.ets(76:35)");
                        Button.backgroundColor(CommonConstants.DDL_COLOR[item.getDDLState()]);
                        Button.height(12);
                        Button.width(12);
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(' ');
                        Text.debugLine("components/IndexTabPages/TaskList.ets(77:13)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    Button.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            // Blank()
            //   .layoutWeight(1)
            // Text(item.subject.toString())
            if (this.isEditing) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Toggle.create({ type: ToggleType.Checkbox, isOn: false });
                        Toggle.debugLine("components/IndexTabPages/TaskList.ets(87:11)");
                        Toggle.onChange((isOn) => {
                            if (isOn)
                                this.deleteTarget.push(item);
                            else {
                                let this_id_index = this.deleteTarget.indexOf(item);
                                this.deleteTarget.splice(this_id_index, 1);
                            }
                        });
                        if (!isInitialRender) {
                            Toggle.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Toggle.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
    }
    // 数据库操作封装
    submitNewTask(taskData) {
        this.taskTable.insertData(taskData, (id) => {
            taskData.id = id;
            taskData.setDDLState();
            this.tasks.push(taskData);
        });
    }
    updateExistingTask(taskData) {
        this.taskTable.updateData(taskData, () => { });
        taskData.setDDLState();
        let new_task = this.tasks;
        this.tasks = [];
        new_task[this.dialogSelectedIndex] = taskData;
        // Logger.debug(`TaskList taskData = ${JSON.stringify(taskData)}`)
        this.tasks = new_task; // 触发 UI 刷新
        this.dialogSelectedIndex = -1;
    }
    deleteSelectedTasks() {
        if (this.deleteTarget.length == 0)
            return;
        for (let i = 0; i < this.deleteTarget.length; ++i) {
            let target = this.deleteTarget[i];
            this.taskTable.deleteData(target, (ret) => {
                if (ret) {
                    let targetIndex = this.tasks.indexOf(target);
                    this.tasks.splice(targetIndex, 1);
                }
            });
        }
        this.deleteTarget = [];
    }
    querySearchTask(searchVal, callback) {
        // 暂时只写了task_name
        this.taskTable.query(`%${searchVal}%`, (searchRes) => {
            this.tasks = searchRes;
            for (let i = 0; i < this.tasks.length; ++i) {
                this.tasks[i].setDDLState();
            }
            Logger.debug(`TaskData = ${JSON.stringify(this.tasks)}`);
            callback();
        }, (searchVal == ''));
    }
    // 数据库操作封装 结束
    // 组件生命周期
    aboutToAppear() {
        Logger.debug(`[TaskList] aboutToAppear`);
        if (this.firstOpen) {
            this.taskTable.getRdbStore(() => {
                this.taskTable.query('', (result) => {
                    this.tasks = result;
                    for (let i = 0; i < this.tasks.length; ++i) {
                        this.tasks[i].setDDLState();
                    }
                    Logger.debug(`TaskData = ${JSON.stringify(this.tasks)}`);
                }, true);
            });
            this.firstOpen = false;
        }
    }
    // 组件生命周期 结束
    // UI
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("components/IndexTabPages/TaskList.ets(166:5)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: (this.isEditing ? Alignment.Bottom : Alignment.BottomEnd) });
            Stack.debugLine("components/IndexTabPages/TaskList.ets(167:7)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/TaskList.ets(168:9)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Navigation.create();
            Navigation.debugLine("components/IndexTabPages/TaskList.ets(169:11)");
            Navigation.titleMode(NavigationTitleMode.Full);
            Navigation.title('清单');
            Navigation.menus([{
                    value: "",
                    icon: this.isEditing ? '../../../resources/base/media/ic_public_edit_filled.svg' : '../../../resources/base/media/ic_public_edit.svg',
                    action: () => {
                        this.deleteTarget = [];
                        this.isEditing = !this.isEditing;
                    }
                }]);
            if (!isInitialRender) {
                Navigation.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            // UI 搜索
            if (!this.isEditing) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Search.create();
                        Search.debugLine("components/IndexTabPages/TaskList.ets(172:34)");
                        Search.onSubmit((value) => {
                            this.querySearchTask(value);
                        });
                        Search.width('90%');
                        if (!isInitialRender) {
                            Search.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Search.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/TaskList.ets(180:13)");
            Column.height('90%');
            Column.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // UI 待办事项界面
            Scroll.create();
            Scroll.debugLine("components/IndexTabPages/TaskList.ets(182:15)");
            // UI 待办事项界面
            Scroll.edgeEffect(EdgeEffect.Spring);
            if (!isInitialRender) {
                // UI 待办事项界面
                Scroll.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/IndexTabPages/TaskList.ets(183:17)");
            Column.padding({ left: 12, right: 12, bottom: 10, top: 10 });
            Column.justifyContent(FlexAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // UI 待办事项列表
            Text.create('未办事项');
            Text.debugLine("components/IndexTabPages/TaskList.ets(185:19)");
            // UI 待办事项列表
            Text.fontSize(20);
            // UI 待办事项列表
            Text.width('100%');
            // UI 待办事项列表
            Text.margin({ bottom: 10, top: 20 });
            // UI 待办事项列表
            Text.textAlign(TextAlign.Start);
            // UI 待办事项列表
            Text.padding({ left: 12, right: 12 });
            if (!isInitialRender) {
                // UI 待办事项列表
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // UI 待办事项列表
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("components/IndexTabPages/TaskList.ets(191:19)");
            List.width('100%');
            List.borderRadius(20);
            List.divider({ strokeWidth: 1 });
            List.margin({ bottom: 20 });
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 未办事项
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    If.create();
                    if (!item.is_completed) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            {
                                const isLazyCreate = true;
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, isLazyCreate);
                                    ListItem.width('100%');
                                    ListItem.backgroundColor(0x9BDEBB);
                                    ListItem.onClick(() => {
                                        if (this.isEditing) {
                                            this.taskItem = item;
                                            this.dialogIsAddNew = false;
                                            this.dialogSelectedIndex = this.tasks.indexOf(item);
                                            this.dialogController.open();
                                        }
                                        else {
                                            this.taskItem = item;
                                            this.dialogController_view.open();
                                        }
                                    });
                                    ListItem.debugLine("components/IndexTabPages/TaskList.ets(194:47)");
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const observedShallowRender = () => {
                                    this.observeComponentCreation(itemCreation);
                                    ListItem.pop();
                                };
                                const observedDeepRender = () => {
                                    this.observeComponentCreation(itemCreation);
                                    this.TaskList_ListItem.bind(this)(item);
                                    ListItem.pop();
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.updateFuncByElmtId.set(elmtId, itemCreation);
                                    this.TaskList_ListItem.bind(this)(item);
                                    ListItem.pop();
                                };
                                if (isLazyCreate) {
                                    observedShallowRender();
                                }
                                else {
                                    observedDeepRender();
                                }
                            }
                        });
                    }
                    else {
                        If.branchId(1);
                    }
                    if (!isInitialRender) {
                        If.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                If.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tasks, forEachItemGenFunction);
            if (!isInitialRender) {
                // 未办事项
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 未办事项
        ForEach.pop();
        List.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('已办事项');
            Text.debugLine("components/IndexTabPages/TaskList.ets(216:19)");
            Text.fontSize(20);
            Text.width('100%');
            Text.margin({ bottom: 10 });
            Text.textAlign(TextAlign.Start);
            Text.padding({ left: 12, right: 12 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("components/IndexTabPages/TaskList.ets(222:19)");
            List.width('100%');
            List.borderRadius(24);
            List.divider({ strokeWidth: 1 });
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 已办事项
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    If.create();
                    if (item.is_completed) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            {
                                const isLazyCreate = true;
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, isLazyCreate);
                                    ListItem.width('100%');
                                    ListItem.backgroundColor(0x9BDEBB);
                                    ListItem.onClick(() => {
                                        if (this.isEditing) {
                                            this.taskItem = item;
                                            this.dialogIsAddNew = false;
                                            this.dialogSelectedIndex = this.tasks.indexOf(item);
                                            this.dialogController.open();
                                        }
                                        else {
                                            this.taskItem = item;
                                            this.dialogController_view.open();
                                        }
                                    });
                                    ListItem.debugLine("components/IndexTabPages/TaskList.ets(225:46)");
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const observedShallowRender = () => {
                                    this.observeComponentCreation(itemCreation);
                                    ListItem.pop();
                                };
                                const observedDeepRender = () => {
                                    this.observeComponentCreation(itemCreation);
                                    this.TaskList_ListItem.bind(this)(item);
                                    ListItem.pop();
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.updateFuncByElmtId.set(elmtId, itemCreation);
                                    this.TaskList_ListItem.bind(this)(item);
                                    ListItem.pop();
                                };
                                if (isLazyCreate) {
                                    observedShallowRender();
                                }
                                else {
                                    observedDeepRender();
                                }
                            }
                        });
                    }
                    else {
                        If.branchId(1);
                    }
                    if (!isInitialRender) {
                        If.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                If.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tasks, forEachItemGenFunction);
            if (!isInitialRender) {
                // 已办事项
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 已办事项
        ForEach.pop();
        List.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("components/IndexTabPages/TaskList.ets(245:19)");
            Text.height(60);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        // UI 待办事项界面
        Scroll.pop();
        Column.pop();
        Navigation.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // UI 右下角的 Fab
            Button.createWithChild({ type: ButtonType.Circle });
            Button.debugLine("components/IndexTabPages/TaskList.ets(269:9)");
            // UI 右下角的 Fab
            Button.backgroundColor(!this.isEditing ? '#ffffff' : '#E84026');
            // UI 右下角的 Fab
            Button.width(60);
            // UI 右下角的 Fab
            Button.height(60);
            // UI 右下角的 Fab
            Button.margin({ bottom: 20, right: (this.isEditing ? 0 : 20) });
            // UI 右下角的 Fab
            Button.onClick(() => {
                if (!this.isEditing) {
                    this.dialogIsAddNew = true;
                    this.taskItem = new TaskData();
                    this.dialogController.open();
                }
                else {
                    if (this.deleteTarget.length != 0) {
                        this.deleteSelectedTasks();
                        this.isEditing = false;
                    }
                }
            });
            if (!isInitialRender) {
                // UI 右下角的 Fab
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (!this.isEditing) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 16777294, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
                        Image.debugLine("components/IndexTabPages/TaskList.ets(271:13)");
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 16777282, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
                        Image.debugLine("components/IndexTabPages/TaskList.ets(273:13)");
                        Image.height(28);
                        Image.width(28);
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        // UI 右下角的 Fab
        Button.pop();
        Stack.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            // UI <临时> 提交入口（只剩刷新按钮了）
            if (!this.isEditing) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("components/IndexTabPages/TaskList.ets(296:28)");
                        Column.padding({ left: 12, right: 12, bottom: 30 });
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("components/IndexTabPages/TaskList.ets(297:9)");
                        Row.justifyContent(FlexAlign.SpaceAround);
                        Row.margin({ top: 30 });
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel('刷新');
                        Button.debugLine("components/IndexTabPages/TaskList.ets(298:11)");
                        Button.backgroundColor('#9BDEBB');
                        Button.onClick(() => {
                            promptAction.showToast({ message: '刷新中' });
                            this.querySearchTask('', () => {
                                promptAction.showToast({ message: '刷新成功' });
                            });
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                    Row.pop();
                    Column.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function getTimeString(date_stamp) {
    let date = new Date();
    date.setTime(date_stamp);
    Logger.debug(`TaskList: datestamp = ${date_stamp}, date = ${date.toLocaleDateString()}`);
    let ds = date.toLocaleDateString().split('/');
    let res = `${ds[2]}/${ds[0]}/${ds[1]}`;
    return res;
}
//# sourceMappingURL=TaskList.js.map