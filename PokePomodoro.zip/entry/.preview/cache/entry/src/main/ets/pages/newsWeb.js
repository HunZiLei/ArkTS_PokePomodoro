import webview from '@ohos:web.webview';
import router from '@ohos:router';
class NewsWeb extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.webController = new webview.WebviewController();
        this.__params = new ObservedPropertyObjectPU(router.getParams(), this, "params");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.webController !== undefined) {
            this.webController = params.webController;
        }
        if (params.params !== undefined) {
            this.params = params.params;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__params.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__params.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get params() {
        return this.__params.get();
    }
    set params(newValue) {
        this.__params.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/newsWeb.ets(11:5)");
            Row.height('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            var _a;
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Web.create({
                src: (_a = this.params) === null || _a === void 0 ? void 0 : _a['url'],
                controller: this.webController
            });
            Web.debugLine("pages/newsWeb.ets(12:7)");
            Web.width("100%");
            Web.height("100%");
            Web.wideViewModeAccess(true);
            Web.textZoomRatio(150);
            if (!isInitialRender) {
                Web.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new NewsWeb(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=newsWeb.js.map