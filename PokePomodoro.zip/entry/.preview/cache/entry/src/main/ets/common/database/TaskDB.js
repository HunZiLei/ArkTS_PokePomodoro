import relationalStore from '@ohos:data.relationalStore';
import Logger from '@bundle:top.handwer.homeworktasklist/entry/ets/common/utils/Logger';
import CommonConstants from '@bundle:top.handwer.homeworktasklist/entry/ets/common/constants/CommonConsts';
export default class TaskDB {
    constructor(tableName, sqlCreateTable, columns) {
        this.rdbStore = null;
        this.RDB_TAG = '[DEBUG_RDB]';
        this.tableName = tableName;
        this.sqlCreateTable = sqlCreateTable;
        this.columns = columns;
    }
    getRdbStore(callback = () => { }) {
        if (!callback || typeof callback === 'undefined' || callback === undefined) {
            Logger.info(this.RDB_TAG, 'getRdbStore() has no callback!');
            return;
        }
        if (this.rdbStore !== null) {
            callback();
            return;
        }
        let context = getContext(this);
        relationalStore.getRdbStore(context, CommonConstants.STORE_CONFIG, (err, rdb) => {
            if (err) {
                Logger.error(this.RDB_TAG, `gerRdbStore() failed, err: ${err}`);
                return;
            }
            this.rdbStore = rdb;
            this.rdbStore.executeSql(this.sqlCreateTable);
            callback();
        });
    }
    test() {
        let vb = {
            id: 1,
            task_name: "123",
            subject: 2
        };
        this.rdbStore.insert('taskTable', vb, (err, ret) => {
            Logger.debug(`Test Error: ${(JSON).stringify(err)}, ret = ${ret}`);
        });
    }
    insertData(data, callback = () => { }) {
        if (!callback || typeof callback === 'undefined' || callback === undefined) {
            Logger.info(this.RDB_TAG, 'insertData() has no callback!');
            return;
        }
        let resFlag = false;
        const valueBucket = data;
        if (this.rdbStore) {
            Logger.debug(this.RDB_TAG, this.tableName);
            this.rdbStore.insert(this.tableName, valueBucket, (err, ret) => {
                if (err) {
                    Logger.error(this.RDB_TAG, `insertData() failed, err: ${err.code}, ${err.name}, ${err.message}, valueB = ${JSON.stringify(valueBucket)}, ret = ${ret}`);
                    callback(false);
                    return;
                }
                Logger.debug(this.RDB_TAG, `insert finished: ${ret}`);
                callback(ret);
            });
        }
    }
    deleteData(predicates, callback = () => { }) {
        if (!callback || typeof callback === 'undefined' || callback === undefined) {
            Logger.info(this.RDB_TAG, 'deleteData() has no callback!');
            return;
        }
        if (this.rdbStore) {
            this.rdbStore.delete(predicates, (err, ret) => {
                if (err) {
                    Logger.error(this.RDB_TAG, `deleteData() failed, err: ${err}`);
                    callback(false);
                    return;
                }
                Logger.info(this.RDB_TAG, `deleteData() finished: ${ret}`);
                callback(true);
            });
        }
    }
    updateData(predicates, data, callback = () => { }) {
        if (!callback || typeof callback === 'undefined' || callback === undefined) {
            Logger.info(this.RDB_TAG, 'updateDate() has no callback!');
            return;
        }
        const valueBucket = data;
        if (this.rdbStore) {
            this.rdbStore.update(valueBucket, predicates, (err, ret) => {
                if (err) {
                    Logger.error(this.RDB_TAG, `updateData() failed, err: ${err}`);
                    callback(false);
                    return;
                }
                Logger.info(this.RDB_TAG, `updateData() finished: ${ret}`);
                callback(true);
            });
        }
    }
    query(predicates, callback = () => { }) {
        if (!callback || typeof callback === 'undefined' || callback === undefined) {
            Logger.info(this.RDB_TAG, 'query() has no callback!');
            return;
        }
        if (this.rdbStore) {
            this.rdbStore.query(predicates, this.columns, (err, resultSet) => {
                if (err) {
                    Logger.error(this.RDB_TAG, `query() failed, err:  ${err}`);
                    return;
                }
                callback(resultSet);
                resultSet.close();
            });
        }
    }
}
//# sourceMappingURL=TaskDB.js.map