export class LoadingDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.hint = '加载中...';
        this.controller = undefined;
        this.__angle = new ObservedPropertySimplePU(0, this, "angle");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.hint !== undefined) {
            this.hint = params.hint;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.angle !== undefined) {
            this.angle = params.angle;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__angle.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__angle.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    setController(ctr) {
        this.controller = ctr;
    }
    get angle() {
        return this.__angle.get();
    }
    set angle(newValue) {
        this.__angle.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Flex.create({ direction: FlexDirection.Column, justifyContent: FlexAlign.Center, alignItems: ItemAlign.Center });
            Flex.debugLine("pages/customDialog/loadingDialog.ets(9:5)");
            Flex.width(100);
            Flex.height(100);
            Flex.backgroundColor('#b3000000');
            Flex.borderRadius(10);
            if (!isInitialRender) {
                Flex.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777273, "type": 20000, params: [], "bundleName": "top.handwer.homeworktasklist", "moduleName": "entry" });
            Image.debugLine("pages/customDialog/loadingDialog.ets(10:7)");
            Context.animation({
                duration: 1500,
                iterations: -1,
            });
            Image.width(50);
            Image.height(50);
            Image.rotate({
                x: 0,
                y: 0,
                z: 1,
                angle: this.angle,
                centerX: '50%',
                centerY: '50%'
            });
            Context.animation(null);
            Image.onAppear(() => {
                this.angle = 360;
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.hint);
            Text.debugLine("pages/customDialog/loadingDialog.ets(29:7)");
            Text.fontSize(14);
            Text.fontColor(Color.White);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Flex.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=loadingDialog.js.map