import { getTabList } from '@bundle:top.handwer.homeworktasklist/entry/ets/model/tabModel';
import display from '@ohos:display';
export class HomeTabs extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.listTab = getTabList();
        this.__tabIndicatorWidth = new ObservedPropertySimplePU(152, this, "tabIndicatorWidth");
        this.__tabIndex = new ObservedPropertySimplePU(0, this, "tabIndex");
        this.tabClick = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.listTab !== undefined) {
            this.listTab = params.listTab;
        }
        if (params.tabIndicatorWidth !== undefined) {
            this.tabIndicatorWidth = params.tabIndicatorWidth;
        }
        if (params.tabIndex !== undefined) {
            this.tabIndex = params.tabIndex;
        }
        if (params.tabClick !== undefined) {
            this.tabClick = params.tabClick;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__tabIndicatorWidth.purgeDependencyOnElmtId(rmElmtId);
        this.__tabIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__tabIndicatorWidth.aboutToBeDeleted();
        this.__tabIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get tabIndicatorWidth() {
        return this.__tabIndicatorWidth.get();
    }
    set tabIndicatorWidth(newValue) {
        this.__tabIndicatorWidth.set(newValue);
    }
    get tabIndex() {
        return this.__tabIndex.get();
    }
    set tabIndex(newValue) {
        this.__tabIndex.set(newValue);
    }
    aboutToAppear() {
        display.getDefaultDisplay((err, data) => {
            if (!err) {
                this.tabIndicatorWidth = data.width / this.listTab.length;
            }
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/customCpt/homeTabs.ets(19:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("pages/customCpt/homeTabs.ets(20:7)");
            Stack.backgroundColor(Color.White);
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/customCpt/homeTabs.ets(21:9)");
            Row.height(35);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Button.createWithChild();
                    Button.debugLine("pages/customCpt/homeTabs.ets(23:13)");
                    Button.layoutWeight(1);
                    Button.height(35);
                    Button.type(ButtonType.Normal);
                    Button.backgroundColor(Color.White);
                    Button.onClick(() => {
                        this.tabIndex = item.id;
                        this.tabClick(item);
                    });
                    if (!isInitialRender) {
                        Button.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(item.name);
                    Text.debugLine("pages/customCpt/homeTabs.ets(24:15)");
                    Text.fontSize(this.tabIndex == item.id ? 15 : 13);
                    Text.fontColor(this.tabIndex == item.id ? $r('app.color.app_theme') : '#000000');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Button.pop();
            };
            this.forEachUpdateFunction(elmtId, this.listTab, forEachItemGenFunction, item => item.tabType, false, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/customCpt/homeTabs.ets(39:9)");
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/customCpt/homeTabs.ets(40:11)");
            Context.animation({ duration: 300 });
            Divider.width(`${this.tabIndicatorWidth}px`);
            Divider.strokeWidth(3);
            Divider.color($r('app.color.app_theme'));
            Divider.lineCap(LineCapStyle.Round);
            Divider.padding({ left: 10, right: 10 });
            Divider.offset({ x: `${this.tabIndex * this.tabIndicatorWidth}px`, y: 0 });
            Context.animation(null);
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Stack.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/customCpt/homeTabs.ets(50:7)");
            Divider.color('#e8e8e8');
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=homeTabs.js.map